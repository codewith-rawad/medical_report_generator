# 🏥 Intelligent Medical Report Generation System

An advanced web-based application for **automatic generation of structured medical reports** from radiological images using **fine-tuned pre-trained models**. This system is built with a **Flask backend** and a **React frontend**, offering high performance, modularity, and a smooth user experience for medical professionals.

---

## ✨ Features

- 🧠 **AI-Powered Diagnosis**: Uses pre-trained models fine-tuned on domain-specific medical datasets.
- 📊 **Automatic Report Generation**: Translates AI-detected findings into coherent, structured medical reports (PDF/Word).
- 🖼️ **Image Upload Interface**: Allows uploading of radiology images for instant analysis.
- 🧾 **Keyword Extraction & Localization**: Identifies keywords and locations of medical findings.
- 🧬 **Two Processing Pipelines**:
  - **Keyword-Based Pipeline**: Extracts clinical context (via voice or text), runs relevant models, and generates a report from extracted keywords.
  - **Feature Vector Pipeline**: Passes images through selected models, aggregates the feature vectors, and feeds them to a DeepSeek model (LoRA fine-tuned) to generate rich medical narratives.

---

## 🛠️ Tech Stack

- **Backend**: Python, Flask, PyTorch, Hugging Face Transformers
- **Frontend**: React, Tailwind CSS
- **Modeling**: YOLO, ResNet, DenseNet, DeepSeek (LLM with LoRA)
- **Document Generation**: python-docx, ReportLab
- **Testing**: pytest

---

## ⚠️ Note on Model Weights

Due to size constraints, **model weights are not included** in the repository. However:

- Directory structure is retained under `backend/ml_models/`.
- The system is designed to load local `.pt` or `.bin` files if placed in the correct directories.
- Please refer to the **project report** for detailed model paths and configuration instructions.


