from app import mongo
from bson import ObjectId

class Specialty:
    collection = mongo.db.specialties

    def __init__(self, name):
        self.name = name

    def save(self):
        Specialty.collection.insert_one({'name': self.name})

    @staticmethod
    def get_all():
        return list(Specialty.collection.find())

    @staticmethod
    def get_by_id(specialty_id):
        return Specialty.collection.find_one({'_id': ObjectId(specialty_id)})

    @staticmethod
    def delete_by_id(specialty_id):
        return Specialty.collection.delete_one({'_id': ObjectId(specialty_id)}) 