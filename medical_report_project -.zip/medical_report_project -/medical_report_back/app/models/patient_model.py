from app import mongo
from datetime import datetime
from bson import ObjectId

class Patient:
    # collection = mongo.db.patients

    def __init__(self, doctor_id, name, age, address):
        self.doctor_id = ObjectId(doctor_id) 
        self.name = name
        self.age = age
        self.address = address
        self.created_at = datetime.utcnow()

    def save(self):
        Patient.collection.insert_one(self.__dict__)

    @staticmethod
    def get_by_doctor(doctor_id):
        return list(Patient.collection.find({"doctor_id": ObjectId(doctor_id)}))

    @staticmethod
    def get_by_id(patient_id):
        return Patient.collection.find_one({"_id": ObjectId(patient_id)})

    @staticmethod
    def delete_by_id(patient_id):
        return Patient.collection.delete_one({"_id": ObjectId(patient_id)})
