import tensorflow as tf
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Dense, Dropout, BatchNormalization
from tensorflow.keras.applications import ResNet50
from tensorflow.keras import regularizers
from tensorflow.keras.optimizers import Adamax
from tensorflow.keras.preprocessing import image
import numpy as np

class_names = ['COVID', 'Lung_Opacity', 'Normal', 'Viral Pneumonia']

def load_resnet_model(weights_path="pretrained_model/weights_epoch_20.weights_covid.h5"):
    base_model = ResNet50(include_top=False, weights="imagenet", input_shape=(224, 224, 3), pooling='max')
    base_model.trainable = False

    x = base_model.output
    x = BatchNormalization()(x)
    x = Dense(256, activation='relu', kernel_regularizer=regularizers.l2(0.01))(x)
    x = BatchNormalization()(x)
    x = Dropout(0.4)(x)
    predictions = Dense(len(class_names), activation='softmax')(x)

    model = Model(inputs=base_model.input, outputs=predictions)

    model.compile(optimizer=Adamax(learning_rate=0.001),
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])

    model.load_weights(weights_path)
    return model

resnet_model = load_resnet_model()

def extract_feature_vector_resnet(image_path):
    img = image.load_img(image_path, target_size=(224, 224))
    img_array = image.img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    intermediate_layer_model = Model(inputs=resnet_model.input,
                                     outputs=resnet_model.layers[-3].output)

    feature_vector = intermediate_layer_model.predict(img_array)
    return feature_vector.squeeze()

image_path = "your_image.jpg"
features = extract_feature_vector_resnet(image_path)
print("Extracted feature vector shape:", features.shape)
