from ultralytics import YOLO
from PIL import Image
import torch


model = YOLO("app/ml_models/pretrained_model/Tb.pt")

def extract_TB_yolo_feature_vector(image_path):

    image = Image.open(image_path).convert("RGB")
 
    results = model.extract_features(image)


    if isinstance(results, list):
        feature_map = results[-1]  # [B, C, H, W]
    else:
        feature_map = results

    feature_vector = torch.mean(feature_map, dim=[2, 3])  

    return feature_vector.squeeze(0).numpy() 
