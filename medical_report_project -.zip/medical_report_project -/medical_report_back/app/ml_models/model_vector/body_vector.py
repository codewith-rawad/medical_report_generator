from ultralytics import YOLO
import torch
import cv2
from PIL import Image
import numpy as np

def load_yolo_segmentation_model():
    return YOLO("app/ml_models/pretrained_model/segmentation_body.pt")

yolo_model = load_yolo_segmentation_model()

def extract_feature_vector_yolo(image_path):
    image = Image.open(image_path).convert("RGB")
    image = image.resize((640, 640))
    image_np = np.array(image).astype(np.float32) / 255.0  
    image_tensor = torch.from_numpy(image_np).permute(2, 0, 1).unsqueeze(0)  

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    image_tensor = image_tensor.to(device)
    yolo_model.to(device)

    with torch.no_grad():
   
        features = yolo_model.model.model[:10](image_tensor)[0]  
        pooled = torch.nn.functional.adaptive_avg_pool2d(features, (1, 1))
        vector = torch.flatten(pooled, 1) 

    return vector.cpu().numpy().flatten()
