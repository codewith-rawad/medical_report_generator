from ultralytics import YOLO
from PIL import Image
import numpy as np
import torch


rib_model = YOLO("app/ml_models/pretrained_model/segmentation_rib.pt")


def extract_feature_vector_from_ribs(image_path):
    image = Image.open(image_path).convert("RGB")
    image = image.resize((640, 640))
    image_np = np.array(image).astype(np.float32) / 255.0  # Normalize
    image_tensor = torch.from_numpy(image_np).permute(2, 0, 1).unsqueeze(0)  # [1, 3, 640, 640]

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    image_tensor = image_tensor.to(device)
    rib_model.to(device)

    with torch.no_grad():
        
        features = rib_model.model.model[:10](image_tensor)[0]  
        pooled = torch.nn.functional.adaptive_avg_pool2d(features, (1, 1))  # [1, C, 1, 1]
        vector = torch.flatten(pooled, 1)  # [1, C]

    return vector.cpu().numpy().flatten()  

