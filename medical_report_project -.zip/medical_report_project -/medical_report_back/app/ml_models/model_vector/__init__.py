from .body_vector import extract_feature_vector_yolo
from .benign_detection_vector import get_feature_vector_yolo
from .detect_segment_vector import extract_feature_vector
from .benign_vector import extract_feature_vector_densenet
from .covid_vector import extract_feature_vector_efficientnet
from .cardiomegaly_vector import extract_feature_vector_cardiomegaly
from .draw_ribs_vector import extract_feature_vector_from_ribs
from .Tb_vector import extract_TB_yolo_feature_vector






model_registry = {
  
    "detect_segment_vector":extract_feature_vector,
    "benign_detection_vector":get_feature_vector_yolo,
    "benign_vector":extract_feature_vector_densenet,
    "body_vector": extract_feature_vector_yolo,
    "covid_vector":extract_feature_vector_efficientnet,
    "cardiomegaly_vector":extract_feature_vector_cardiomegaly,
    "draw_ribs_vector":extract_feature_vector_from_ribs,
    "Tb_vector":extract_TB_yolo_feature_vector
  
}
