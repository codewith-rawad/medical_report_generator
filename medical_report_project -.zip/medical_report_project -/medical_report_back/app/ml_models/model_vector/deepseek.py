
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

model_name = "deepseek-ai/deepseek-llm-7b-base"
tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
base_model = AutoModelForCausalLM.from_pretrained(
    model_name,
    trust_remote_code=True,
    device_map="auto",
    load_in_4bit=True
)


lora_path = "app/ml_models/peft_weights" 
model = PeftModel.from_pretrained(base_model, lora_path)
model.eval()

def generate_report_from_vector(vector, max_tokens=300):
    """
    Takes a feature vector (numpy array) and generates a medical report using DeepSeek.
    """

    vector_text = " ".join(map(str, vector.tolist()))
    prompt = (
        "You are a medical assistant AI. Based on the following image features, "
        "generate a detailed medical report in formal English:\n" + vector_text
    )

    inputs = tokenizer(prompt, return_tensors="pt").to(device)

    with torch.no_grad():
        outputs = model.generate(
            input_ids=inputs["input_ids"],
            attention_mask=inputs["attention_mask"],
            max_new_tokens=max_tokens,
            do_sample=True,
            top_p=0.9,
            temperature=0.7
        )

    result = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return result
