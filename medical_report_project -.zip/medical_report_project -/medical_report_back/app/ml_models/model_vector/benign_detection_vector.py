from ultralytics import YOLO
from PIL import Image
import torch
import torchvision.transforms as T


model = YOLO("app/ml_models/pretrained_model/benign_detection.pt")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)


transform = T.Compose([
    T.Resize((640, 640)),
    T.ToTensor(),
])

def get_feature_vector_yolo(image_path):

    img = Image.open(image_path).convert("RGB")
    img_t = transform(img).to(device).unsqueeze(0) 


   
    with torch.no_grad():
      
    
        
        features_vector = torch.flatten(features, start_dim=1)  

    return features_vector.cpu().numpy().flatten()
