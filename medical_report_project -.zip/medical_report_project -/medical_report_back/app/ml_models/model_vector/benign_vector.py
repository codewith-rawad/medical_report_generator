import torch
import torch.nn as nn
from torchvision import models, transforms
from PIL import Image
import numpy as np

class_names = ['benign', 'malignant']

def load_densenet_model(weights_path="app/ml_models/pretrained_model/model_weights_benign.pth"):

    model = models.densenet121(pretrained=False)
    num_features = model.classifier.in_features
 
    model.classifier = nn.Sequential(
        nn.Linear(num_features, 512),
        nn.ReLU(),
        nn.Dropout(0.5),
        nn.Linear(512, 2)
    )
   
    state_dict = torch.load(weights_path, map_location=torch.device('cpu'))
    model.load_state_dict(state_dict)
    model.eval()
    return model


densenet_model = load_densenet_model()

def extract_feature_vector_densenet(image_path):
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5]*3, std=[0.5]*3)
    ])

    image = Image.open(image_path).convert("RGB")
    image_tensor = transform(image).unsqueeze(0) 

    with torch.no_grad():
 
        features = densenet_model.features(image_tensor)
        out = nn.functional.relu(features, inplace=True)
        out = nn.functional.adaptive_avg_pool2d(out, (1, 1))
        features_vector = torch.flatten(out, 1) 

    return features_vector.cpu().numpy().flatten()

def predict_class_densenet(image_path):
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5]*3, std=[0.5]*3)
    ])

    image = Image.open(image_path).convert("RGB")
    image_tensor = transform(image).unsqueeze(0)

    with torch.no_grad():
        output = densenet_model(image_tensor)
        probabilities = torch.nn.functional.softmax(output, dim=1)
        predicted_class = torch.argmax(probabilities, dim=1).item()

    return class_names[predicted_class]
