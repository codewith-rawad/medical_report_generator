from ultralytics import YOLO
import torch
from PIL import Image
import torchvision.transforms as transforms


def load_yolo_feature_model():
    return YOLO("app/ml_models/pretrained_model/multi.pt")


yolo_model = load_yolo_feature_model()


def preprocess_image(image_path, size=640):
    image = Image.open(image_path).convert("RGB")
    transform = transforms.Compose([
        transforms.Resize((size, size)),
        transforms.ToTensor(),
    ])
    return transform(image).unsqueeze(0)  # [1, 3, H, W]

def extract_feature_vector(image_path):
    image_tensor = preprocess_image(image_path).to("cpu") 
    yolo_model.eval()

    with torch.no_grad():
      
        outputs = yolo_model.model.model[:24](image_tensor)  
        feature_vector = outputs[-1].squeeze()  

    return feature_vector  # Tensor

