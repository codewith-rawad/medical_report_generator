import torch
import torch.nn as nn
from torchvision import transforms, models
from PIL import Image

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

val_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.Grayscale(num_output_channels=1),
    transforms.ToTensor(),
    transforms.Normalize([0.5], [0.5])
])

def load_feature_model():
    weights_path = "app/ml_models/pretrained_model/model_epoch10_cardiomegaly.pth"

    base_model = models.densenet121(pretrained=False)
    base_model.features.conv0 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
    base_model.classifier = nn.Identity()  # Remove classification layer for feature extraction

    state_dict = torch.load(weights_path, map_location=device)
    base_model.load_state_dict(state_dict, strict=False)

    base_model = base_model.to(device)
    base_model.eval()
    return base_model

feature_model = load_feature_model()

def extract_feature_vector_cardiomegaly(image_path):
    image = Image.open(image_path).convert('L')
    input_tensor = val_transform(image).unsqueeze(0).to(device)

    with torch.no_grad():
        features = feature_model(input_tensor)

    return features.cpu().numpy().flatten()
