import torch
from PIL import Image
import torchvision.transforms as transforms


fracture_model = YOLO("app/ml_models/pretrained_model/ribs_yolo_fraction.pt")
seg_model = YOLO("app/ml_models/pretrained_model/segmentation_rib.pt")


def preprocess_image(image_path, image_size=640):
    image = Image.open(image_path).convert("RGB")
    transform = transforms.Compose([
        transforms.Resize((image_size, image_size)),
        transforms.ToTensor(),
    ])
    return transform(image).unsqueeze(0)  


def extract_feature_vector(model, image_path, image_size=640):
    image_tensor = preprocess_image(image_path, image_size).to(model.device)

    with torch.no_grad():

        features = model.model.model[:-1](image_tensor)

        feature_map = features[-1]  

        feature_vector = torch.mean(feature_map, dim=[2,3])  

    return feature_vector.squeeze(0).cpu().numpy()


