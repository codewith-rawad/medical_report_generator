from ultralytics import YOLO
import numpy as np


model = YOLO("app/ml_models/pretrained_model/segmentation_rib.pt") 

print(model.names)


def detect_boxes_only(image_path):
    results = model(image_path, imgsz=640)[0]

    detections = []
    if results.boxes is None or len(results.boxes) == 0:
        return ["No detections"]

    for box in results.boxes:
        cls_id = int(box.cls[0].item())
        conf = round(float(box.conf[0].item()), 3)
        x1, y1, x2, y2 = map(round, box.xyxy[0].tolist())

        detection_str = (
            f"Class: {model.names[cls_id]}, "
            f"Confidence: {conf}, "
            f"BBox: Top-left({x1},{y1}), Bottom-right({x2},{y2})"
        )
        
        detections.append(detection_str)

    return detections
