# model_detection.py

from ultralytics import YOLO
from PIL import Image, ImageDraw
import io
import base64
from .body import extract_segment_boxes

model = YOLO("app/ml_models/pretrained_model/benign_detection.pt")
allowed_classes = {"benign", "malignant"}

def detect_benign_with_anatomy(image_path):
    results = model(image_path, imgsz=640)[0]
    regions = extract_segment_boxes(image_path)

    image = Image.open(image_path).convert("RGB")
    draw = ImageDraw.Draw(image)
    detections = []

    if results.boxes is None or len(results.boxes) == 0:
        return ["No tumor detected"], image_to_base64(image)

    for box in results.boxes:
        cls_id = int(box.cls[0].item())
        cls_name = model.names[cls_id]

        if cls_name not in allowed_classes:
            continue

        x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
        cx = (x1 + x2) // 2
        cy = (y1 + y2) // 2

        region_name = "unknown"
        for region in regions:
            rx, ry, rw, rh = region["x"], region["y"], region["width"], region["height"]
            if rx <= cx <= rx + rw and ry <= cy <= ry + rh:
                position = "upper" if cy < ry + rh // 2 else "lower"
                region_name = f"{position} {region['name']}"
                break

        detections.append(f"Tumor detected at {region_name}")


        draw.rectangle([x1, y1, x2, y2], outline="red", width=2)
        draw.text((x1, y1 - 10), "tumor", fill="red")

    if not detections:
        return ["No tumor detected"], image_to_base64(image)

    return detections, image_to_base64(image)


def image_to_base64(pil_image):
    buffered = io.BytesIO()
    pil_image.save(buffered, format="JPEG")
    return base64.b64encode(buffered.getvalue()).decode("utf-8")
