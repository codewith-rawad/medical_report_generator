import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, BatchNormalization
from tensorflow.keras.applications import ResNet50
from tensorflow.keras import regularizers
from tensorflow.keras.optimizers import Adamax
from tensorflow.keras.preprocessing import image
import numpy as np

class_names = ['COVID', 'Lung_Opacity', 'Normal', 'Viral Pneumonia'] 

def load_resnet50_model(weights_path="pretrained_model/weights_epoch_20.weights_covid.h5"):
    base_model = ResNet50(include_top=False, weights="imagenet", input_shape=(224, 224, 3), pooling='max')
    base_model.trainable = False

    model = Sequential([
        base_model,
        BatchNormalization(),
        Dense(256, activation='relu', kernel_regularizer=regularizers.l2(0.01)),
        BatchNormalization(),
        Dropout(0.4),
        Dense(len(class_names), activation='softmax')
    ])

    model.compile(optimizer=Adamax(learning_rate=0.001),
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])

    model.load_weights(weights_path)
    return model


resnet50_model = load_resnet50_model()


def extract_keywords_resnet50(image_path):
    img = image.load_img(image_path, target_size=(224, 224))
    img_array = image.img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0) 

    predictions = resnet50_model.predict(img_array)
    predicted_class = np.argmax(predictions[0]) 

    keyword = class_names[predicted_class]
    return [keyword]
