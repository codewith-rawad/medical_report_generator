
import torch
from PIL import Image
from ultralytics import YOLO


model = YOLO("app/ml_models/pretrained_model/ribs_yolo_fraction.pt")  

def detect_fractures_with_boxes(image_path):
    results = model(image_path, imgsz=1024)[0]

    detections = []
    if results.boxes is None or len(results.boxes) == 0:
        print("🚫 No fracture detected in the ribs.")
        return ["No fracture detected in ribs"]

    for box in results.boxes:
        cls_id = int(box.cls[0].item())
        conf = float(box.conf[0].item())
        x1, y1, x2, y2 = box.xyxy[0].tolist()

        detection = (
            f"Prediction: {model.names[cls_id]}",      
            f"Confidence: {round(conf, 3)}",            
            f"Top-left corner: ({round(x1)}, {round(y1)})",  
            f"Bottom-right corner: ({round(x2)}, {round(y2)})" 
        )
        detections.append(detection)

    return detections

