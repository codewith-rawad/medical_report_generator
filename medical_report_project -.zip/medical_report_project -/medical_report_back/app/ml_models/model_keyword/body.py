

from ultralytics import YOLO
import torch
import cv2
from PIL import Image

CLASS_NAMES = {
    0: 'background',
    1: 'heart',
    2: 'right lung',
    3: 'left lung'
}

def load_segmentation_model():
    return YOLO("app/ml_models/pretrained_model/segmentation_body.pt")

segmentation_model = load_segmentation_model()

def extract_segment_boxes(image_path, min_area=1000):
    original_image = Image.open(image_path)
    orig_w, orig_h = original_image.size
    input_size = 640

    results = segmentation_model(image_path, imgsz=input_size, device=0 if torch.cuda.is_available() else 'cpu')[0]
    segments = []

    if results.masks is not None and results.boxes is not None:
        masks = results.masks.data
        boxes = results.boxes
        classes = results.boxes.cls.cpu().numpy().astype(int)

        for i, (mask, box_cls) in enumerate(zip(masks, classes)):
            mask_np = mask.cpu().numpy()
            mask_uint8 = (mask_np * 255).astype('uint8')
            contours, _ = cv2.findContours(mask_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            for contour in contours:
                x, y, w, h = cv2.boundingRect(contour)

                scale_x = orig_w / input_size
                scale_y = orig_h / input_size
                x = int(x * scale_x)
                y = int(y * scale_y)
                w = int(w * scale_x)
                h = int(h * scale_y)

                area = w * h
                if area >= min_area and box_cls in CLASS_NAMES:
                    name = CLASS_NAMES[box_cls]
                    segments.append({
                        "name": name,
                        "x": x,
                        "y": y,
                        "width": w,
                        "height": h
                    })

    return segments
