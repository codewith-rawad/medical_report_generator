from ultralytics import YOLO
from PIL import Image
import numpy as np
import io
import base64
import torch
import torchvision.transforms.functional as TF


seg_model = YOLO("app/ml_models/pretrained_model/segmentation_rib.pt")


def image_to_base64(pil_image):
    buffered = io.BytesIO()
    pil_image.save(buffered, format="JPEG")
    return base64.b64encode(buffered.getvalue()).decode("utf-8")


def resize_mask(mask_tensor, target_size):
    # mask_tensor: (1, H, W) أو (H, W)
    if mask_tensor.ndim == 2:
        mask_tensor = mask_tensor.unsqueeze(0)  # (1, H, W)
    mask_pil = TF.to_pil_image(mask_tensor.float())
    resized_mask_pil = mask_pil.resize(target_size, resample=Image.NEAREST)
    resized_mask = np.array(resized_mask_pil) > 0
    return resized_mask

def draw_segmentation_masks(image_path):
    image = Image.open(image_path).convert("RGB")
    image_np = np.array(image)
    image_size = image.size  # (width, height)

    results = seg_model(image_path, imgsz=640)[0]

    if results.masks is not None:
        for mask_tensor in results.masks.data:
            mask_tensor = mask_tensor.cpu()
            resized_mask = resize_mask(mask_tensor, image_size) 

            colored_mask = np.zeros_like(image_np)
            colored_mask[resized_mask] = [0, 0, 255]

           
            image_np = np.where(
                colored_mask > 0,
                (0.5 * image_np + 0.5 * colored_mask).astype(np.uint8),
                image_np
            )

    result_image = Image.fromarray(image_np)
    return image_to_base64(result_image)
