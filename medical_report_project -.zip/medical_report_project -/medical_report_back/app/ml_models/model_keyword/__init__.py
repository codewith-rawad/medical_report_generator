
# from .covid import extract_keywords_efficientnet
from .benign import extract_keywords_densenet
# from .pneumonia import extract_keywords_resnet
from .cardiomegaly import extract_keywords_cardiomegaly
from .fracture import detect_fractures_with_boxes
from .rib_seg import detect_boxes_only
from .detect_segment import  detect_fractures_and_match_to_ribs
from .detect_effusion import detect_effusion_
from .multi import detect_multi_with_anatomy
from .Tb import detect_TB_with_anatomy
from .benign_detection import detect_benign_with_anatomy
from .draw_ribs import draw_segmentation_masks
from .draw_lung_heart import draw_lung_segmentation_masks







model_registry = {
    # "covid-opacity-pneumonia": extract_keywords_densenet,
    "tumor-classifier": extract_keywords_densenet,               
    "tumor-localization": detect_benign_with_anatomy,
    "tb-detection": detect_TB_with_anatomy,
    "cardiomegaly": extract_keywords_cardiomegaly,
    "rib-fracture": detect_fractures_and_match_to_ribs,
    "aortic-conditions": detect_multi_with_anatomy,
    "draw-ribs": draw_segmentation_masks,
    "draw-lungs-heart": draw_lung_segmentation_masks,
    "pleural-effusion": detect_effusion_,
    # "detect_segment_vector":extract_feature_vector,
    # "benign_detection_vector":get_feature_vector_yolo,
    # "benign_vector":extract_feature_vector_densenet,
    # "body_vector": extract_feature_vector_yolo,
    # "covid_vector":extract_feature_vector_efficientnet,
    # "cardiomegaly_vector":extract_feature_vector_cardiomegaly,
    # "draw_ribs_vector":extract_feature_vector_from_ribs,
    # "Tb_vector":extract_TB_yolo_feature_vector

   
}
