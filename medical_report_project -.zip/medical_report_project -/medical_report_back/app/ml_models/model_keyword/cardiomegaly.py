import torch
import torch.nn as nn
from torchvision import transforms, models
from PIL import Image
from .body import extract_segment_boxes  

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

val_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.Grayscale(num_output_channels=1),
    transforms.ToTensor(),
    transforms.Normalize([0.5], [0.5])
])

def load_binary_model():
    weights_path = "app/ml_models/pretrained_model/model_epoch10_cardiomegaly.pth"
    
    model = models.densenet121(pretrained=False)
    model.features.conv0 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
    model.classifier = nn.Linear(model.classifier.in_features, 1)
    
    state_dict = torch.load(weights_path, map_location=device)
    model.load_state_dict(state_dict, strict=False)
    
    model = model.to(device)
    model.eval()
    return model

binary_model = load_binary_model()

def fallback_method_for_cardiomegaly(image_path):
    segments = extract_segment_boxes(image_path)

    heart_width = 0
    right_lung_width = 0
    left_lung_width = 0

    for seg in segments:
        if seg["name"] == "heart":
            heart_width = seg["width"]
        elif seg["name"] == "right lung":
            right_lung_width = seg["width"]
        elif seg["name"] == "left lung":
            left_lung_width = seg["width"]

    total_width = heart_width + right_lung_width + left_lung_width

    if total_width == 0:
        return [" heart condition uncertain"]

    ratio = heart_width / total_width

    if ratio > 0.4:
        return [" heart appears enlarged based on segmentation"]
    else:
        return [" heart size appears normal based on segmentation"]

def extract_keywords_cardiomegaly(image_path):
    image = Image.open(image_path).convert('L')
    input_tensor = val_transform(image).unsqueeze(0).to(device)
    
    with torch.no_grad():
        output = binary_model(input_tensor)
        prob = torch.sigmoid(output).item()

    if prob >= 0.6:
        return [" heart is cardiomegaly"]
    elif prob <= 0.4:
        return [" heart is normal"]
    else:
        return fallback_method_for_cardiomegaly(image_path)
