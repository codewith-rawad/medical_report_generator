from app.ml_models.model_keyword import model_registry

def run_selected_models(image_path, selected_models):
    keywords = []
    images_base64 = []

    for model_name in selected_models:
        extractor = model_registry.get(model_name)
        if not extractor:
            continue

        if model_name in ["draw-lungs-heart", "draw-ribs"]:
            image_base64 = extractor(image_path)
            images_base64.append({"model": model_name, "image_base64": image_base64})

        elif model_name == "tumor-localization":
            detections, image_base64 = extractor(image_path)
            images_base64.append({"model": model_name, "image_base64": image_base64})

            if detections and "No tumor detected" not in detections:
    
                classifier = model_registry.get("tumor-classifier")
                if classifier:
                    tumor_type = classifier(image_path) 
             
                    for det in detections:
                        keywords.append(f"{tumor_type[0]}  {det.split('tumor')[-1]}")
            else:
                keywords += detections

        elif model_name in ["tb-detection", "rib-fracture", "aortic-conditions"]:
            detections, image_base64 = extractor(image_path)
            keywords += detections
            images_base64.append({"model": model_name, "image_base64": image_base64})

        else:
            keywords += extractor(image_path)

    return list(set(keywords)), images_base64
