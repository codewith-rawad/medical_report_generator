from ultralytics import YOLO
import torch
from PIL import Image
import numpy as np
import io
import base64
import torchvision.transforms.functional as TF


def load_segmentation_model():
    return YOLO("app/ml_models/pretrained_model/segmentation_body.pt")

segmentation_model = load_segmentation_model()

def image_to_base64(pil_image):
    buffered = io.BytesIO()
    pil_image.save(buffered, format="JPEG")
    return base64.b64encode(buffered.getvalue()).decode("utf-8")


def resize_mask(mask_tensor, target_size):

    if mask_tensor.ndim == 2:
        mask_tensor = mask_tensor.unsqueeze(0)  # (1, H, W)
    mask_pil = TF.to_pil_image(mask_tensor.float())
    resized_mask_pil = mask_pil.resize(target_size, resample=Image.NEAREST)
    resized_mask = np.array(resized_mask_pil) > 0
    return resized_mask

def draw_lung_segmentation_masks(image_path):
    original_image = Image.open(image_path).convert("RGB")
    image_np = np.array(original_image)
    orig_size = original_image.size  # (width, height)

  
    results = segmentation_model(image_path, imgsz=640, device=0 if torch.cuda.is_available() else 'cpu')[0]

    if results.masks is None:
       
        return None, "No segmentation masks found"

    masks = results.masks.data.cpu()
  

    if results.boxes is None or results.boxes.cls is None:
        
        return None, "No class info found"

    classes = results.boxes.cls.cpu().numpy().astype(int)
  

    if len(masks) != len(classes):
  
        return None, "Mismatch between masks and classes"

    CLASS_COLORS = {
        1: (255, 0, 0),   
        2: (0, 255, 0),    
        3: (0, 0, 255),    
    }

    for i, mask_tensor in enumerate(masks):
        class_id = classes[i]
       
        if class_id not in CLASS_COLORS:
            print(f"⛔  {class_id}")
            continue

        resized_mask = resize_mask(mask_tensor, orig_size)
        colored_mask = np.zeros_like(image_np)
        colored_mask[resized_mask] = CLASS_COLORS[class_id]


        alpha = 0.5
        image_np = np.where(
            colored_mask > 0,
            (alpha * image_np + (1 - alpha) * colored_mask).astype(np.uint8),
            image_np
        )

    final_image = Image.fromarray(image_np)

    return image_to_base64(final_image), 


if __name__ == "__main__":
    img_path = "path_to_your_image.jpg" 
    img_base64, status = draw_lung_segmentation_masks(img_path)
    if status == "Success":
        print("done")
      
    else:
        print("wrong", status)