from ultralytics import YOLO
from PIL import Image, ImageDraw
import torch
import io
import base64
from .body import extract_segment_boxes

model = YOLO("app/ml_models/pretrained_model/multi.pt")
allowed_classes = {"Aortic enlargement", "Atelectasis", "Calcification"}

def detect_multi_with_anatomy(image_path):
    results = model(image_path, imgsz=832)[0]
    detections = []
    
    # Load original image
    image = Image.open(image_path).convert("RGB")
    draw = ImageDraw.Draw(image)

    regions = extract_segment_boxes(image_path)

    if results.boxes is None or len(results.boxes) == 0:
        return ["No detection"], image_to_base64(image)

    for box in results.boxes:
        cls_id = int(box.cls[0].item())
        cls_name = model.names[cls_id]

        if cls_name not in allowed_classes:
            continue

        conf = float(box.conf[0].item())
        x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
        cx = (x1 + x2) // 2
        cy = (y1 + y2) // 2

        region_name = "unknown"
        for region in regions:
            rx, ry, rw, rh = region["x"], region["y"], region["width"], region["height"]
            if rx <= cx <= rx + rw and ry <= cy <= ry + rh:
                position = "upper" if cy < ry + rh // 2 else "lower"
                region_name = f"{position} {region['name']}"
                break

        detection = f"{cls_name} (Confidence {round(conf, 3)}) at {region_name}"
        detections.append(detection)

        # Draw box and label
        draw.rectangle([x1, y1, x2, y2], outline="red", width=2)
        draw.text((x1, y1 - 10), cls_name, fill="red")

    if not detections:
        return ["No detection"], image_to_base64(image)

    return detections, image_to_base64(image)

def image_to_base64(pil_image):
    buffered = io.BytesIO()
    pil_image.save(buffered, format="JPEG")
    return base64.b64encode(buffered.getvalue()).decode("utf-8")
