from ultralytics import YOLO
from PIL import Image, ImageDraw, ImageFont
import torch
import io
import base64


fracture_model = YOLO("app/ml_models/pretrained_model/ribs_yolo_fraction.pt")
seg_model = YOLO("app/ml_models/pretrained_model/segmentation_rib.pt")


def image_to_base64(pil_image):
    buffered = io.BytesIO()
    pil_image.save(buffered, format="JPEG")
    return base64.b64encode(buffered.getvalue()).decode("utf-8")


def detect_ribs(image_path):
    results = seg_model(image_path, imgsz=640)[0]
    boxes = []
    if results.boxes is not None:
        for box in results.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
            boxes.append((x1, y1, x2, y2))
    return boxes


def detect_fractures(image_path):
    results = fracture_model(image_path, imgsz=1024)[0]
    boxes = []
    if results.boxes is not None:
        for box in results.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
            boxes.append((x1, y1, x2, y2))
    return boxes


def assign_rib_positions(rib_boxes, image_width):
    ribs = []
    for box in rib_boxes:
        x1, y1, x2, y2 = box
        x_center = (x1 + x2) // 2
        y_center = (y1 + y2) // 2
        ribs.append({"box": box, "x_center": x_center, "y_center": y_center})

    x_split = image_width // 2
    left_ribs = [rib for rib in ribs if rib["x_center"] < x_split]
    right_ribs = [rib for rib in ribs if rib["x_center"] >= x_split]

    left_ribs_sorted = sorted(left_ribs, key=lambda x: x["y_center"])[:12]
    right_ribs_sorted = sorted(right_ribs, key=lambda x: x["y_center"])[:12]

    for i, rib in enumerate(left_ribs_sorted):
        rib["rib_number"] = i + 1
        rib["side"] = "right"
    for i, rib in enumerate(right_ribs_sorted):
        rib["rib_number"] = i + 1
        rib["side"] = "left"

    return left_ribs_sorted + right_ribs_sorted


def compute_iou(boxA, boxB):
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])

    inter_area = max(0, xB - xA) * max(0, yB - yA)
    if inter_area == 0:
        return 0

    boxA_area = (boxA[2] - boxA[0]) * (boxA[3] - boxA[1])
    boxB_area = (boxB[2] - boxB[0]) * (boxB[3] - boxB[1])
    return inter_area / float(boxA_area + boxB_area - inter_area)


def center_distance(boxA, boxB):
    ax = (boxA[0] + boxA[2]) / 2
    ay = (boxA[1] + boxA[3]) / 2
    bx = (boxB[0] + boxB[2]) / 2
    by = (boxB[1] + boxB[3]) / 2
    return ((ax - bx)**2 + (ay - by)**2)**0.5


def match_fractures_to_ribs(fracture_boxes, ribs_data):
    matches = []
    for fbox in fracture_boxes:
        best_match = None
        best_score = float("inf")  
        for rib in ribs_data:
            iou = compute_iou(fbox, rib["box"])
            if iou > 0.2:  
                score = 1 - iou
            else:
                score = center_distance(fbox, rib["box"]) / 1000  

            if score < best_score:
                best_score = score
                best_match = rib

        if best_match:
            matches.append({
                "rib_number": best_match["rib_number"],
                "side": best_match["side"],
                "fracture_box": fbox,
                "rib_box": best_match["box"]
            })
    return matches


def detect_fractures_and_match_to_ribs(image_path):
    image = Image.open(image_path).convert("RGB")
    draw = ImageDraw.Draw(image)
    image_width, _ = image.size

    rib_boxes = detect_ribs(image_path)
    ribs_data = assign_rib_positions(rib_boxes, image_width)

    for rib in ribs_data:
        x1, y1, x2, y2 = rib["box"]
        draw.rectangle([x1, y1, x2, y2], outline="blue", width=2)
        draw.text((x1, y1 - 10), f"Rib {rib['rib_number']} ({rib['side']})", fill="blue")

    fracture_boxes = detect_fractures(image_path)
    matches = match_fractures_to_ribs(fracture_boxes, ribs_data)

    results = []
    if not matches:
        results.append("No fracture detected in ribs")
    else:
        for match in matches:
            rib_num = match['rib_number']
            side = match['side']
            x1, y1, x2, y2 = match['fracture_box']
            results.append(f"Fracture in rib {rib_num} ({side} side)")
            draw.rectangle([x1, y1, x2, y2], outline="red", width=3)
            draw.text((x1, y2 + 5), f"Fracture", fill="red")

    return results, image_to_base64(image)
