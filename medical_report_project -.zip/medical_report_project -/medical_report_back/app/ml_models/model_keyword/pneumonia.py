import torch
import torchvision.transforms as transforms
from PIL import Image
import torch.nn as nn
from sklearn.preprocessing import LabelEncoder

val_test_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225])
])

labels = ['Pneumothorax', 'Pneumonia', 'cancer']
le = LabelEncoder()
le.fit(labels)

def load_model(weights_path):
    model = torch.hub.load('pytorch/vision:v0.14.0', 'resnet18', pretrained=False)
    num_ftrs = model.fc.in_features
    model.fc = nn.Linear(num_ftrs, len(labels))  
    
    model.load_state_dict(torch.load(weights_path, map_location=torch.device('cpu')))
    model.eval()
    return model

def extract_keywords_resnet(image_path):
    model = load_model("app/ml_models/pretrained_model/model_weights-pnomonia_Pneumonia.pth")
    image = Image.open(image_path).convert('RGB')
    image_tensor = val_test_transform(image).unsqueeze(0) 
    
    with torch.no_grad():
        outputs = model(image_tensor)
        probabilities = torch.softmax(outputs, dim=1)
    
    pred_index = torch.argmax(probabilities, dim=1).item()
    pred_label = le.inverse_transform([pred_index])[0]
    

    return [pred_label]

