from .body import extract_segment_boxes 

def detect_effusion_(image_path, threshold=50):
    """
    image_path: path to the chest X-ray image
    threshold: height difference between lungs to consider as effusion
    """
    segments = extract_segment_boxes(image_path)
    right_lung = None
    left_lung = None

    for seg in segments:
        if seg["name"] == "right lung":
            right_lung = seg
        elif seg["name"] == "left lung":
            left_lung = seg

    if not right_lung or not left_lung:
        return ["lungs_not_detected"]

    height_right = right_lung["height"]
    height_left = left_lung["height"]
    diff = abs(height_right - height_left)

    if diff >= threshold:
        shorter_lung = "right" if height_right < height_left else "left"
        return [f"Pleural Effusion in {shorter_lung} lung"]
    else:
        return ["no_Pleural Effusion"]
