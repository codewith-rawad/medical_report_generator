from flask import Blueprint, request, jsonify
from app.models.user_model import User
from app.models.patient_model import Patient
from app.models.MedicalCondition import MedicalCondition
from app.models.specialty_model import Specialty
from bson import ObjectId
from datetime import datetime

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/users', methods=['GET'])
def get_users():
    try:
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 10))
        skip = (page - 1) * per_page
        search = request.args.get('search', '')
        role = request.args.get('role', '')

        query = {}
        if role:
            query["role"] = role
        if search:
            query["$or"] = [
                {"name": {"$regex": search, "$options": "i"}},
                {"email": {"$regex": search, "$options": "i"}},
                {"phone": {"$regex": search, "$options": "i"}}
            ]

        users_cursor = User.collection.find(query).skip(skip).limit(per_page)
        total_users = User.collection.count_documents(query)

        users = []
        for user in users_cursor:
            user['_id'] = str(user['_id'])
            if user.get('specialty_id'):
                specialty = Specialty.collection.find_one({"_id": ObjectId(user['specialty_id'])})
                user['specialty'] = specialty['name'] if specialty else None
            users.append(user)

        return jsonify({
            "users": users,
            "total": total_users,
            "page": page,
            "per_page": per_page,
            "total_pages": (total_users + per_page - 1) // per_page
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/users/<user_id>', methods=['GET'])
def get_user(user_id):
    try:
        user = User.collection.find_one({"_id": ObjectId(user_id)})
        if not user:
            return jsonify({"message": "User not found"}), 404
        
        user['_id'] = str(user['_id'])
        if user.get('specialty_id'):
            specialty = Specialty.collection.find_one({"_id": ObjectId(user['specialty_id'])})
            user['specialty'] = specialty['name'] if specialty else None
        
        return jsonify(user), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/users/<user_id>', methods=['DELETE'])
def delete_user(user_id):
    try:
        user_obj_id = ObjectId(user_id)
        
        # Check if user exists
        user = User.collection.find_one({"_id": user_obj_id})
        if not user:
            return jsonify({"message": "User not found"}), 404

        # If user is a doctor, delete their patients and medical conditions
        if user.get('role') == 'doctor':
            patients = Patient.collection.find({'doctorId': user_obj_id})
            for patient in patients:
                MedicalCondition.collection.delete_many({'patientId': patient['_id']})
                Patient.collection.delete_one({'_id': patient['_id']})

        # Delete the user
        result = User.collection.delete_one({"_id": user_obj_id})
        if result.deleted_count == 0:
            return jsonify({"message": "User not found"}), 404

        return jsonify({"message": "User and all related data deleted successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/users/<user_id>', methods=['PUT'])
def update_user(user_id):
    try:
        data = request.get_json()
        updates = {
            "name": data.get("name"),
            "email": data.get("email"),
            "phone": data.get("phone"),
            "address": data.get("address"),
            "age": data.get("age"),
            "specialty_id": data.get("specialty_id"),
            "profile_pic": data.get("profile_pic"),
            "updated_at": datetime.utcnow()
        }
        
        # Remove None values
        updates = {k: v for k, v in updates.items() if v is not None}
        
        result = User.collection.update_one(
            {"_id": ObjectId(user_id)},
            {"$set": updates}
        )
        
        if result.matched_count == 0:
            return jsonify({"message": "User not found"}), 404
            
        return jsonify({"message": "User updated successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/doctors', methods=['POST'])
def create_doctor():
    try:
        data = request.get_json()
        
        # Check if email already exists
        if User.collection.find_one({"email": data["email"]}):
            return jsonify({"message": "Email already exists"}), 400
            
        doctor = User(
            name=data["name"],
            email=data["email"],
            password=data["password"],
            role="doctor",
            phone=data.get("phone"),
            address=data.get("address"),
            age=data.get("age"),
            specialty_id=data.get("specialty_id"),
            profile_pic=data.get("profile_pic")
        )
        
        doctor.save()
        
        return jsonify({
            "message": "Doctor created successfully",
            "doctor_id": str(doctor._id)
        }), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Patient Management
@admin_bp.route('/patients', methods=['GET'])
def get_patients():
    try:
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 10))
        skip = (page - 1) * per_page
        search = request.args.get('search', '')
        doctor_id = request.args.get('doctor_id', '')

        query = {}
        if search:
            query["$or"] = [
                {"name": {"$regex": search, "$options": "i"}},
                {"address": {"$regex": search, "$options": "i"}}
            ]
        if doctor_id:
            query["doctorId"] = ObjectId(doctor_id)

        patients_cursor = Patient.collection.find(query).skip(skip).limit(per_page)
        total_patients = Patient.collection.count_documents(query)

        patients = []
        for patient in patients_cursor:
            patient['_id'] = str(patient['_id'])
            patient['doctorId'] = str(patient['doctorId'])
            
            # Get doctor details
            doctor = User.collection.find_one({"_id": ObjectId(patient['doctorId'])})
            if doctor:
                patient['doctor_name'] = doctor.get('name', '')
                
            patients.append(patient)

        return jsonify({
            "patients": patients,
            "total": total_patients,
            "page": page,
            "per_page": per_page,
            "total_pages": (total_patients + per_page - 1) // per_page
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/patients/<patient_id>', methods=['GET'])
def get_patient(patient_id):
    try:
        patient = Patient.collection.find_one({"_id": ObjectId(patient_id)})
        if not patient:
            return jsonify({"message": "Patient not found"}), 404
        
        patient['_id'] = str(patient['_id'])
        patient['doctorId'] = str(patient['doctorId'])
        
        # Get doctor details
        doctor = User.collection.find_one({"_id": ObjectId(patient['doctorId'])})
        if doctor:
            patient['doctor_name'] = doctor.get('name', '')
            if doctor.get('specialty_id'):
                specialty = Specialty.collection.find_one({"_id": ObjectId(doctor['specialty_id'])})
                patient['doctor_specialty'] = specialty['name'] if specialty else None
        
        # Get medical conditions
        conditions = MedicalCondition.collection.find({"patientId": ObjectId(patient_id)})
        patient['conditions'] = [{
            '_id': str(cond['_id']),
            'clinical_case': cond.get('clinical_case'),
            'created_at': cond.get('created_at'),
            'content': cond.get('content')
        } for cond in conditions]
        
        return jsonify(patient), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/patients', methods=['POST'])
def create_patient():
    try:
        data = request.get_json()
        
        patient = Patient(
            doctor_id=data["doctor_id"],
            name=data["name"],
            age=data.get("age"),
            address=data.get("address")
        )
        
        patient.save()
        
        return jsonify({
            "message": "Patient created successfully",
            "patient_id": str(patient._id)
        }), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/patients/<patient_id>', methods=['PUT'])
def update_patient(patient_id):
    try:
        data = request.get_json()
        updates = {
            "name": data.get("name"),
            "age": data.get("age"),
            "address": data.get("address"),
            "doctorId": ObjectId(data.get("doctor_id")) if data.get("doctor_id") else None
        }
        
        # Remove None values
        updates = {k: v for k, v in updates.items() if v is not None}
        
        result = Patient.collection.update_one(
            {"_id": ObjectId(patient_id)},
            {"$set": updates}
        )
        
        if result.matched_count == 0:
            return jsonify({"message": "Patient not found"}), 404
            
        return jsonify({"message": "Patient updated successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/patients/<patient_id>', methods=['DELETE'])
def delete_patient(patient_id):
    try:
        # Delete medical conditions first
        MedicalCondition.collection.delete_many({"patientId": ObjectId(patient_id)})
        
        # Delete patient
        result = Patient.collection.delete_one({"_id": ObjectId(patient_id)})
        if result.deleted_count == 0:
            return jsonify({"message": "Patient not found"}), 404
            
        return jsonify({"message": "Patient and all related conditions deleted successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Medical Conditions Management
@admin_bp.route('/conditions', methods=['GET'])
def get_conditions():
    try:
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 10))
        skip = (page - 1) * per_page
        patient_id = request.args.get('patient_id', '')
        doctor_id = request.args.get('doctor_id', '')

        query = {}
        if patient_id:
            query["patientId"] = ObjectId(patient_id)
        if doctor_id:
            # Get all patients for this doctor, then get their conditions
            patient_ids = [p['_id'] for p in Patient.collection.find({"doctorId": ObjectId(doctor_id)})]
            query["patientId"] = {"$in": patient_ids}

        conditions_cursor = MedicalCondition.collection.find(query).skip(skip).limit(per_page)
        total_conditions = MedicalCondition.collection.count_documents(query)

        conditions = []
        for condition in conditions_cursor:
            condition['_id'] = str(condition['_id'])
            condition['patientId'] = str(condition['patientId'])
            condition['userId'] = str(condition['userId'])
            
            # Get patient details
            patient = Patient.collection.find_one({"_id": ObjectId(condition['patientId'])})
            if patient:
                condition['patient_name'] = patient.get('name', '')
                condition['doctorId'] = str(patient.get('doctorId', ''))
                
                # Get doctor details
                doctor = User.collection.find_one({"_id": ObjectId(patient.get('doctorId', ''))})
                if doctor:
                    condition['doctor_name'] = doctor.get('name', '')
            
            conditions.append(condition)

        return jsonify({
            "conditions": conditions,
            "total": total_conditions,
            "page": page,
            "per_page": per_page,
            "total_pages": (total_conditions + per_page - 1) // per_page
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/conditions/<condition_id>', methods=['GET'])
def get_condition(condition_id):
    try:
        condition = MedicalCondition.collection.find_one({"_id": ObjectId(condition_id)})
        if not condition:
            return jsonify({"message": "Condition not found"}), 404
        
        condition['_id'] = str(condition['_id'])
        condition['patientId'] = str(condition['patientId'])
        condition['userId'] = str(condition['userId'])
        
        # Get patient details
        patient = Patient.collection.find_one({"_id": ObjectId(condition['patientId'])})
        if patient:
            condition['patient_name'] = patient.get('name', '')
            condition['doctorId'] = str(patient.get('doctorId', ''))
            
            # Get doctor details
            doctor = User.collection.find_one({"_id": ObjectId(patient.get('doctorId', ''))})
            if doctor:
                condition['doctor_name'] = doctor.get('name', '')
        
        return jsonify(condition), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/conditions/<condition_id>', methods=['DELETE'])
def delete_condition(condition_id):
    try:
        result = MedicalCondition.collection.delete_one({"_id": ObjectId(condition_id)})
        if result.deleted_count == 0:
            return jsonify({"message": "Condition not found"}), 404
            
        return jsonify({"message": "Condition deleted successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Specialty Management
@admin_bp.route('/specialties', methods=['GET'])
def get_specialties():
    try:
        specialties = Specialty.collection.find()
        return jsonify([{
            "_id": str(spec["_id"]),
            "name": spec["name"]
        } for spec in specialties]), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/specialties', methods=['POST'])
def create_specialty():
    try:
        data = request.get_json()
        specialty = Specialty(name=data["name"])
        specialty.save()
        return jsonify({"message": "Specialty created successfully"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/specialties/<specialty_id>', methods=['PUT'])
def update_specialty(specialty_id):
    try:
        data = request.get_json()
        result = Specialty.collection.update_one(
            {"_id": ObjectId(specialty_id)},
            {"$set": {"name": data["name"]}}
        )
        if result.matched_count == 0:
            return jsonify({"message": "Specialty not found"}), 404
        return jsonify({"message": "Specialty updated successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/specialties/<specialty_id>', methods=['DELETE'])
def delete_specialty(specialty_id):
    try:
        # Check if any doctors are using this specialty
        doctors_count = User.collection.count_documents({"specialty_id": specialty_id})
        if doctors_count > 0:
            return jsonify({
                "message": "Cannot delete specialty. There are doctors associated with it.",
                "doctors_count": doctors_count
            }), 400
            
        result = Specialty.collection.delete_one({"_id": ObjectId(specialty_id)})
        if result.deleted_count == 0:
            return jsonify({"message": "Specialty not found"}), 404
            
        return jsonify({"message": "Specialty deleted successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Dashboard Statistics
@admin_bp.route('/stats', methods=['GET'])
def get_stats():
    try:
        total_doctors = User.collection.count_documents({"role": "doctor"})
        total_patients = Patient.collection.count_documents({})
        total_conditions = MedicalCondition.collection.count_documents({})
        total_specialties = Specialty.collection.count_documents({})
        
        return jsonify({
            "total_doctors": total_doctors,
            "total_patients": total_patients,
            "total_conditions": total_conditions,
            "total_specialties": total_specialties
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500