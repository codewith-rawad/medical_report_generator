from flask import Blueprint, request, jsonify
from app.models.MedicalCondition import MedicalCondition
from bson import ObjectId
from app import mongo
from datetime import datetime

condition_bp = Blueprint('condition', __name__)


@condition_bp.route('/conditions', methods=['POST'])
def add_condition():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "Request must be JSON"}), 415

        required_fields = ['patient_id','pdfBase64', 'image_base64', 'user_id']
        if not all(data.get(field) for field in required_fields):
            return jsonify({"error": "Missing required fields"}), 400

        patient = mongo.db.patients.find_one({"_id": ObjectId(data['patient_id'])})
        if not patient:
            return jsonify({"error": "Patient not found"}), 404

        condition = MedicalCondition(
            patient_id=data['patient_id'],
            patient_name=patient.get("name", "Unknown"),
            age=patient.get("age", "Unknown"),
            clinical_case=data['clinical_case'],
            report_base64=data['pdfBase64'],
            content=data.get('report', ""),
            image_base64=data['image_base64'],
            user_id=data['user_id']
        )
        condition.save()

        return jsonify({"message": "Medical condition saved successfully"}), 201

    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500


@condition_bp.route('/conditions', methods=['GET'])
def get_conditions():
    try:
        patient_id = request.args.get('patient_id', '').strip()
        clinical_case = request.args.get('clinical_case', '').strip()
        date_filter = request.args.get('date', '').strip()
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 4))

        query = {}
        if patient_id:
            query['patient_id'] = patient_id
        if clinical_case:
            query['clinical_case'] = {"$regex": clinical_case, "$options": "i"}
        if date_filter:
            try:

                date_obj = datetime.strptime(date_filter, '%Y-%m-%d')
                start = datetime(date_obj.year, date_obj.month, date_obj.day)
                end = datetime(date_obj.year, date_obj.month, date_obj.day, 23, 59, 59)
                query['created_at'] = {"$gte": start, "$lte": end}
            except ValueError:
                return jsonify({"error": "Invalid date format. Use YYYY-MM-DD."}), 400

        total_count = MedicalCondition.collection.count_documents(query)
        total_pages = (total_count + limit - 1) // limit
        skip = (page - 1) * limit

        conditions_cursor = (
            MedicalCondition.collection
            .find(query)
            .skip(skip)
            .limit(limit)
            .sort("created_at", -1)
        )

        result = []
        for cond in conditions_cursor:
            result.append({
                "_id": str(cond.get('_id')),
                "patient_id": cond.get('patient_id'),
                "patient_name": cond.get('patient_name'),
                "age": cond.get('age'),
                "clinical_case": cond.get('clinical_case'),
                "report_base64": cond.get('report_base64'),
                "content": cond.get('content', ""),
                "image_base64": cond.get('image_base64'),
                "created_at": cond.get('created_at').isoformat() if cond.get('created_at') else None
            })

        return jsonify({
            "conditions": result,
            "total_pages": total_pages,
            "current_page": page,
            "total_count": total_count
        }), 200

    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500



@condition_bp.route('/conditions/<string:condition_id>', methods=['DELETE'])
def delete_condition(condition_id):
    try:
        result = MedicalCondition.delete_by_id(condition_id)
        if result.deleted_count == 0:
            return jsonify({"error": "Condition not found"}), 404
        return jsonify({"message": "Condition deleted successfully"}), 200
    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500
