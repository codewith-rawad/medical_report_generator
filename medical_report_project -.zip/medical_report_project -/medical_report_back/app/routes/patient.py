from flask import Blueprint, request, jsonify
from app import mongo
from math import ceil
from bson import ObjectId

patient_bp = Blueprint('patient', __name__)

@patient_bp.route('/patients', methods=['POST'])
def add_patient():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "Request must be JSON"}), 400

        doctor_id = data.get('doctor_id')
        name = data.get('name')
        age = data.get('age')
        address = data.get('address', "")
        medical_cases = data.get('medical_cases', [])

        if not all([doctor_id, name, age]):
            return jsonify({"error": "Doctor ID, name, and age are required"}), 400

        new_patient = {
            "doctor_id": doctor_id,
            "name": name,
            "age": age,
            "address": address,
            "medical_cases": medical_cases
        }

        mongo.db.patients.insert_one(new_patient)
        return jsonify({"message": "Patient added successfully"}), 201

    except Exception as e:
        return jsonify({"error": f"Failed to add patient: {str(e)}"}), 500

@patient_bp.route('/patients', methods=['GET'])
def get_patients():
    doctor_id = request.args.get('doctor_id')
    if not doctor_id:
        return jsonify({"error": "Doctor ID is required"}), 400

    try:
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 2))
        if page < 1 or limit < 1:
            raise ValueError()
    except ValueError:
        return jsonify({"error": "Page and limit must be positive integers"}), 400

    try:
        total_patients = mongo.db.patients.count_documents({"doctor_id": doctor_id})
        total_pages = ceil(total_patients / limit)
        skip = (page - 1) * limit

        cursor = mongo.db.patients.find({"doctor_id": doctor_id}).skip(skip).limit(limit)

        patients = []
        for p in cursor:
            patients.append({
                "_id": str(p["_id"]),
                "name": p.get("name"),
                "age": p.get("age"),
                "address": p.get("address"),
                "medical_cases": p.get("medical_cases", [])
            })

        return jsonify({
            "patients": patients,
            "page": page,
            "limit": limit,
            "total_patients": total_patients,
            "total_pages": total_pages
        }), 200

    except Exception as e:
        return jsonify({"error": f"Failed to retrieve patients: {str(e)}"}), 500


@patient_bp.route('/patients/<string:patient_id>', methods=['DELETE'])
def delete_patient(patient_id):
    try:
   
        result = mongo.db.patients.delete_one({"_id": ObjectId(patient_id)})
        if result.deleted_count == 0:
            return jsonify({"error": "Patient not found"}), 404

        
        mongo.db.medical_conditions.delete_many({"patient_id": patient_id})

        return jsonify({"message": "Patient and associated conditions deleted successfully"}), 200

    except Exception as e:
        return jsonify({"error": f"Failed to delete patient: {str(e)}"}), 500





@patient_bp.route('/patients/<string:patient_id>', methods=['GET'])
def get_patient_by_id(patient_id):
    try:
        patient = mongo.db.patients.find_one({"_id": ObjectId(patient_id)})
        if not patient:
            return jsonify({"error": "Patient not found"}), 404

        return jsonify({
            "_id": str(patient["_id"]),
            "name": patient.get("name"),
            "age": patient.get("age"),
        }), 200

    except Exception as e:
        return jsonify({"error": f"Failed to retrieve patient: {str(e)}"}), 500
