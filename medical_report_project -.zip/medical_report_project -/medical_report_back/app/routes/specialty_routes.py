from flask import Blueprint, jsonify
from app.models.specialty_model import Specialty

specialty_bp = Blueprint('specialty', __name__)

@specialty_bp.route('/specialties', methods=['GET'])
def get_specialties():
    specialties = Specialty.get_all()
  
    for s in specialties:
        s['_id'] = str(s['_id'])
    return jsonify(specialties), 200 