from flask import Blueprint, request, jsonify
import google.generativeai as genai
import json
import os

nlp_bp = Blueprint('nlp', __name__)

genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
gemini_model = genai.GenerativeModel("gemini-1.5-flash")

@nlp_bp.route('/parse_patient_info', methods=['POST'])
def parse_patient_info():
    data = request.get_json()
    if not data or 'transcript' not in data:
        return jsonify({'message': 'Transcript is required'}), 400

    transcript = data['transcript']

    prompt =  (
    "You are a highly intelligent AI medical assistant. From the following transcript, extract the following:\n\n"
    "1. \"patient_name\": Name of the patient (if available).\n"
    "2. \"age\": Age of the patient (if mentioned).\n"
    "3. \"clinical_case\": A short, clear summary of the clinical complaint.\n"
    "4. \"selected_models\": A list of model IDs (as strings) to be used for diagnosis, based on the transcript.\n\n"
    "Understand the clinical meaning of symptoms, diagnoses, and keywords, and match them with the most relevant models below.\n\n"

    "Here are the available models with detailed purposes:\n\n"

    "1. covid-opacity-pneumonia => Detects **COVID-19**, **pneumonia**, and **lung opacity**.\n"
    "   Use if transcript mentions: **cough**, **fever**, **shortness of breath**, **opacity**, **infiltrate**, or suspected **viral/bacterial pneumonia**.\n\n"

    "2. tb-detection => Detects **tuberculosis** from chest X-rays.\n"
    "   Use if transcript includes: **chronic cough**, **night sweats**, **weight loss**, **hemoptysis**, or past TB history.\n\n"

    "3. draw-lungs-heart => Draws **lungs and heart** contours for better visualization.\n"
    "   Use if user needs anatomical **context**, or when overlapping pathologies are discussed (e.g., heart & lung diseases).\n\n"

    "4. pleural-effusion => Detects **pleural effusion** (fluid around the lungs).\n"
    "   Use if transcript mentions: **fluid**, **blunted costophrenic angles**, **dyspnea**, **chest heaviness**, or **dullness on percussion**.\n\n"

    "5. cardiomegaly => Detects **cardiomegaly** (enlarged heart).\n"
    "   Use if transcript includes: **fatigue**, **shortness of breath**, **palpitations**, **large heart**, **CHF**, or known **heart failure**.\n\n"

    "6. aortic-conditions => Detects **aortic calcification** or **aortic enlargement**.\n"
    "   Use if transcript mentions: **aortic aneurysm**, **hypertension**, **calcified aorta**, or **chronic chest pain**.\n\n"

    "7. tumor-classifier => Classifies **chest tumors** as **benign or malignant**.\n"
    "   Use if transcript mentions: **mass**, **nodule**, **tumor**, **opacity suspicious for neoplasm**.\n\n"

    "8. tumor-localization => Localizes **tumor/nodule position**.\n"
    "   Use if exact tumor **location is clinically important** (e.g., for surgery planning, biopsy guidance).\n\n"

    "9. rib-fracture => Detects **rib fractures** and locates them accurately.\n"
    "   Use if transcript includes: **rib trauma**, **pain on movement or breathing**, **fall**, **localized sharp chest pain**.\n\n"

    "10. draw-ribs => Draws **rib outlines** and highlights fracture sites.\n"
    "    Use if user needs **visual rib anatomy**, to **support fracture detection** or track healing.\n\n"

    "⚠️ Output must be valid JSON, exactly like this:\n"
    "{\n"
    "  \"patient_name\": \"...\",\n"
    "  \"age\": 45,\n"
    "  \"clinical_case\": \"...\",\n"
    "  \"selected_models\": [\"covid-opacity-pneumonia\", \"tb-detection\"]\n"
    "}\n\n"

    f"Transcript:\n{transcript}"
)



    try:
        response = gemini_model.generate_content(prompt)
        content = response.text.strip()
        cleaned_json = content.replace("```json", "").replace("```", "").strip()
        parsed = json.loads(cleaned_json)

        # Ensure age is an integer
        if parsed.get("age"):
            try:
                parsed["age"] = int(parsed["age"])
            except (ValueError, TypeError):
                pass

        return jsonify(parsed), 200

    except json.JSONDecodeError:
        return jsonify({"error": "Gemini response is not valid JSON", "raw": content}), 500

    except Exception as e:
        return jsonify({"error": str(e)}), 500
