from flask import Blueprint, request, jsonify
import os
from werkzeug.utils import secure_filename
from bson import ObjectId
from app import mongo
from app.ml_models.model_vector.extractor_vector import run_selected_vector_models

ml_vector_models_bp = Blueprint('ml_vector_models', name)

@ml_vector_models_bp.route('/generate_vector_report', methods=['POST'])
def generate_vector_report():
    if 'image' not in request.files:
        return jsonify({'error': 'No image uploaded'}), 400

    image = request.files['image']
    selected_models = request.form.getlist('models')
    user_id = request.form.get('user_id')

    if not selected_models:
        return jsonify({'error': 'No models selected'}), 400
    if not user_id:
        return jsonify({'error': 'Missing user ID'}), 400

    UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    filename = secure_filename(image.filename)
    image_path = os.path.join(UPLOAD_FOLDER, filename)
    with open(image_path, "wb") as f:
        f.write(image.read())

    try:
   
        report, combined_vector = run_selected_vector_models(image_path, selected_models, return_vector=True)

        result = mongo.db.reports.insert_one({
            "user_id": ObjectId(user_id),
            "filename": filename,
            "selected_models": selected_models,
            "feature_vector": combined_vector.tolist(),  
            "report": report
        })

        image_id = str(result.inserted_id)
        os.remove(image_path)

        return jsonify({
            "report": report,
            "used_models": selected_models,
            "image_id": image_id
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500