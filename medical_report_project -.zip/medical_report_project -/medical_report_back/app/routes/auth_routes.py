from flask import Blueprint, request, jsonify
from app.models.user_model import User
from flask_bcrypt import Bcrypt
import jwt
import datetime
import re

auth_bp = Blueprint('auth', __name__)
bcrypt = Bcrypt()

SECRET_KEY = 'your_secret_key'


def validate_email(email):
    """Validate email format"""
    if not email:
        return False, "Email is required"

    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(pattern, email):
        return False, "Please enter a valid email address"
    
    return True, "Email is valid"


def validate_password(password):
    """Validate password strength"""
    if not password:
        return False, "Password is required"
    
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter"
    
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter"
    
    if not re.search(r'\d', password):
        return False, "Password must contain at least one number"
    
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        return False, "Password must contain at least one special character"
    
    return True, "Password is valid"


@auth_bp.route('/signup', methods=['POST'])
def register():
    data = request.get_json()

    if not data.get('email') or not data.get('password') or not data.get('name'):
        return jsonify({"message": "Email, name, and password are required"}), 400

    # Validate email
    email_valid, email_message = validate_email(data['email'])
    if not email_valid:
        return jsonify({"message": email_message}), 400

    # Validate password
    password_valid, password_message = validate_password(data['password'])
    if not password_valid:
        return jsonify({"message": password_message}), 400

    role = 'doctor'  

    if User.find_by_email(data['email']):
        return jsonify({"message": "User already exists"}), 400

    hashed_password = bcrypt.generate_password_hash(data['password']).decode('utf-8')

    new_user = User(
        name=data['name'],
        email=data['email'],
        password=hashed_password,
        role=role,
    )
    new_user.save()

    return jsonify({"message": "Doctor account created successfully"}), 201


@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()

    if not data.get('email') or not data.get('password'):
        return jsonify({"message": "Email and password are required"}), 400

    # Validate email format
    email_valid, email_message = validate_email(data['email'])
    if not email_valid:
        return jsonify({"message": email_message}), 400

    user = User.find_by_email(data['email'])
    if not user:
        return jsonify({"message": "User not found"}), 404

    if not bcrypt.check_password_hash(user['password'], data['password']):
        return jsonify({"message": "Invalid credentials"}), 401

    token = jwt.encode({
        'user_id': str(user['_id']),
        'role': user['role'],
        'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=2)
    }, SECRET_KEY, algorithm='HS256')

    user_data = {
        "_id": str(user["_id"]),
        "name": user.get("name", ""),
        "email": user.get("email", ""),
        "role": user.get("role", ""),
        "phone": user.get("phone", ""),
        "address": user.get("address", ""),
        "age": user.get("age", ""),
        "profile_pic": user.get("profile_pic", "")
    }

    return jsonify({
        'message': 'Login successful',
        'token': token,
        'user': user_data
    }), 200


@auth_bp.route('/validate-email', methods=['POST'])
def validate_email_route():
    """Endpoint to validate email format"""
    data = request.get_json()
    email = data.get('email', '')
    
    is_valid, message = validate_email(email)
    
    return jsonify({
        'valid': is_valid,
        'message': message
    }), 200 if is_valid else 400


@auth_bp.route('/validate-password', methods=['POST'])
def validate_password_route():
    """Endpoint to validate password strength"""
    data = request.get_json()
    password = data.get('password', '')
    
    is_valid, message = validate_password(password)
    
    return jsonify({
        'valid': is_valid,
        'message': message
    }), 200 if is_valid else 400
