from flask import Blueprint, request, jsonify
from bson import ObjectId
from datetime import datetime
from docxtpl import DocxTemplate
import base64
from app import mongo
from docx2pdf import convert
import tempfile
import os
import pythoncom

direct_report_bp = Blueprint('direct_report', __name__)

@direct_report_bp.route('/generate_direct_report', methods=['POST'])
def generate_direct_report():

    data = request.get_json()
    user_id = data.get("user_id")
    patient_id = data.get("patient_id")
    findings = data.get("report")  
    

    if not all([user_id, patient_id, findings]):
        return jsonify({"error": "Missing required fields"}), 400

    pythoncom.CoInitialize()
    try:
        user = mongo.db.users.find_one({"_id": ObjectId(user_id)})
        if not user:
            return jsonify({"error": "User not found"}), 404
        
        patient = mongo.db.patients.find_one({"_id": ObjectId(patient_id)})
        if not patient:
            return jsonify({"error": "Patient not found"}), 404

        user_name = user.get("name", "Unknown Doctor")
        patient_name = patient.get("name", "Unknown Patient")
        patient_age = patient.get("age", "Unknown")

        report_text = findings

        template_path = "templates/MEDICAL_REPORT.docx"
        doc = DocxTemplate(template_path)

        context = {
            "patient_name": patient_name,
            "doctor_name": user_name,
            "age": patient_age,
            "date": datetime.now().strftime("%Y-%m-%d"),
            "generated_report": report_text
        }
        doc.render(context)

        with tempfile.TemporaryDirectory() as tmpdirname:
            docx_path = os.path.join(tmpdirname, "direct_report.docx")
            pdf_path = os.path.join(tmpdirname, "direct_report.pdf")

            doc.save(docx_path)
            convert(docx_path, pdf_path)

            with open(docx_path, "rb") as f_docx:
                word_bytes = f_docx.read()
            word_base64 = base64.b64encode(word_bytes).decode("utf-8")

            with open(pdf_path, "rb") as f_pdf:
                pdf_bytes = f_pdf.read()
            pdf_base64 = base64.b64encode(pdf_bytes).decode("utf-8")

        report_doc = {
            "user_id": ObjectId(user_id),
            "patient_id": ObjectId(patient_id),
            "report_text": report_text,
            "docx_base64": word_base64,
            "pdf_base64": pdf_base64,
            "is_direct": True,
            "created_at": datetime.utcnow()
        }
        mongo.db.reports.insert_one(report_doc)

        return jsonify({
            "success": True,
            "report": report_text,
            "docx_base64": word_base64,
            "pdf_base64": pdf_base64,
            "message": "done"
        })

    except Exception as e:
        return jsonify({
            "error": str(e),
            "message": "faild"
        }), 500
    finally:
        pythoncom.CoUninitialize()
