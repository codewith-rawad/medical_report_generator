import pytest
import os
import tempfile
from app import create_app
from app.extensions import mongo, bcrypt
from unittest.mock import Mock, patch

@pytest.fixture
def app():
  

    db_fd, db_path = tempfile.mkstemp()
    
    app = create_app()
    app.config.update({
        'TESTING': True,
        'MONGO_URI': 'mongodb://localhost:27017/test_medical_db',
        'SECRET_KEY': 'test-secret-key'
    })

    with app.test_client() as client:
        with app.app_context():
            yield app
    
 
    os.close(db_fd)
    os.unlink(db_path)

@pytest.fixture
def client(app):
    """A test client for the app."""
    return app.test_client()

@pytest.fixture
def runner(app):
    """A test runner for the app's Click commands."""
    return app.test_cli_runner()

@pytest.fixture
def mock_mongo():
    """Mock MongoDB for testing."""
    with patch('app.extensions.mongo') as mock:
        yield mock

@pytest.fixture
def sample_user():
    """Sample user data for testing."""
    return {
        'email': 'test@example.com',
        'password': 'TestPass123!',
        'name': 'Test User',
        'role': 'doctor'
    }

@pytest.fixture
def sample_admin_user():
    """Sample admin user data for testing."""
    return {
        'email': 'admin@example.com',
        'password': 'AdminPass123!',
        'name': 'Admin User',
        'role': 'admin'
    }

@pytest.fixture
def sample_patient():
    """Sample patient data for testing."""
    return {
        'doctor_id': '507f1f77bcf86cd799439011',
        'name': 'John Doe',
        'age': 30,
        'address': '123 Main St',
   
    }

@pytest.fixture
def auth_headers(client, sample_user):
 
    try:
        # Register user first
        response = client.post('/api/signup', json=sample_user)
        if response.status_code == 201:
            # Login to get token
            login_response = client.post('/api/login', json={
                'email': sample_user['email'],
                'password': sample_user['password']
            })
            if login_response.status_code == 200:
                data = login_response.get_json()
                token = data.get('token')
                if token:
                    return {'Authorization': f'Bearer {token}'}
    except Exception:
        pass
    return {}

@pytest.fixture
def admin_headers(client, sample_admin_user):

    try:
        # Register admin user first
        response = client.post('/api/signup', json=sample_admin_user)
        if response.status_code == 201:
            # Login to get token
            login_response = client.post('/api/login', json={
                'email': sample_admin_user['email'],
                'password': sample_admin_user['password']
            })
            if login_response.status_code == 200:
                data = login_response.get_json()
                token = data.get('token')
                if token:
                    return {'Authorization': f'Bearer {token}'}
    except Exception:
        pass
    return {}

@pytest.fixture
def mock_jwt_decode():
    """Mock JWT decode for testing."""
    with patch('jwt.decode') as mock:
        mock.return_value = {
            'user_id': '507f1f77bcf86cd799439011',
            'email': 'test@example.com',
            'role': 'doctor'
        }
        yield mock

@pytest.fixture
def mock_user_model():
    """Mock User model for testing."""
    with patch('app.models.user_model.User') as mock:
        mock.find_by_email.return_value = {
            '_id': '507f1f77bcf86cd799439011',
            'email': 'test@example.com',
            'password': bcrypt.generate_password_hash('TestPass123!').decode('utf-8'),
            'name': 'Test User',
            'role': 'doctor'
        }
        mock.find_by_id.return_value = {
            '_id': '507f1f77bcf86cd799439011',
            'email': 'test@example.com',
            'name': 'Test User',
            'role': 'doctor'
        }
        yield mock 