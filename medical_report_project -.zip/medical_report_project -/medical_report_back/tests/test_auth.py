import pytest
import json
from app.extensions import bcrypt

class TestAuthRoutes:
    """Test authentication routes."""
    
    def test_signup_success(self, client, sample_user):
        """Test successful user registration."""
        response = client.post('/api/signup', json=sample_user)
        assert response.status_code == 201
        data = response.get_json()
        assert 'message' in data
        assert data['message'] == 'Doctor account created successfully'
    
    def test_signup_existing_user(self, client, sample_user):
        """Test registration with existing email."""
        # Register user first time
        client.post('/api/signup', json=sample_user)
        
        # Try to register again with same email
        response = client.post('/api/signup', json=sample_user)
        assert response.status_code == 400
        data = response.get_json()
        assert 'message' in data
    
    def test_signup_invalid_data(self, client):
        """Test registration with invalid data."""
        invalid_user = {'email': 'invalid-email'}
        response = client.post('/api/signup', json=invalid_user)
        assert response.status_code == 400
    
    def test_signup_missing_fields(self, client):
        """Test registration with missing required fields."""
        incomplete_user = {'email': 'test@example.com'}
        response = client.post('/api/signup', json=incomplete_user)
        assert response.status_code == 400
    
    def test_login_success(self, client, sample_user):
        """Test successful login."""
        # Register user first
        client.post('/api/signup', json=sample_user)
        
        # Login
        response = client.post('/api/login', json={
            'email': sample_user['email'],
            'password': sample_user['password']
        })
        assert response.status_code == 200
        data = response.get_json()
        assert 'token' in data
        assert 'user' in data
    
    def test_login_invalid_credentials(self, client, sample_user):
        """Test login with invalid credentials."""
        # Register user first
        client.post('/api/signup', json=sample_user)
        
        # Try to login with wrong password
        response = client.post('/api/login', json={
            'email': sample_user['email'],
            'password': 'wrongpassword'
        })
        assert response.status_code == 401
    
    def test_login_nonexistent_user(self, client):
        """Test login with non-existent user."""
        response = client.post('/api/login', json={
            'email': 'nonexistent@example.com',
            'password': 'password123'
        })
        assert response.status_code == 404
    
    def test_login_missing_fields(self, client):
        """Test login with missing fields."""
        response = client.post('/api/login', json={})
        assert response.status_code == 400
    
    def test_validate_email_valid(self, client):
        """Test email validation with valid email."""
        response = client.post('/api/validate-email', json={
            'email': 'test@example.com'
        })
        assert response.status_code == 200
    
    def test_validate_email_invalid(self, client):
        """Test email validation with invalid email."""
        response = client.post('/api/validate-email', json={
            'email': 'invalid-email'
        })
        assert response.status_code == 400
    
    def test_validate_password_valid(self, client):
        """Test password validation with valid password."""
        response = client.post('/api/validate-password', json={
            'password': 'ValidPass123!'
        })
        assert response.status_code == 200
    
    def test_validate_password_invalid(self, client):
        """Test password validation with invalid password."""
        response = client.post('/api/validate-password', json={
            'password': 'weak'
        })
        assert response.status_code == 400 