import pytest
import json

class TestAdminRoutes:
    """Test admin routes."""
    
    def test_admin_route_without_auth(self, client):
        """Test admin route without authentication."""
        response = client.get('/api/admin/users')
        assert response.status_code == 401
    
    def test_admin_route_with_user_auth(self, client, auth_headers):
        """Test admin route with regular user authentication."""
        if auth_headers:
            response = client.get('/api/admin/users', headers=auth_headers)
            assert response.status_code == 403
    
    def test_admin_route_with_admin_auth(self, client, admin_headers):
        """Test admin route with admin authentication."""
        if admin_headers:
            response = client.get('/api/admin/users', headers=admin_headers)
            assert response.status_code == 200
    
    def test_get_all_users(self, client, admin_headers):
        """Test getting all users as admin."""
        if admin_headers:
            response = client.get('/api/admin/users', headers=admin_headers)
            assert response.status_code == 200
            data = response.get_json()
            assert 'users' in data
    
    def test_delete_user(self, client, admin_headers, sample_user):
        """Test deleting a user as admin."""
        if admin_headers:
            # First create a user to delete
            client.post('/api/signup', json=sample_user)
            
            # Get the user ID (we need to find the user first)
            # Since we don't have a direct way to get user ID, we'll test the route structure
            # The actual deletion would require the user ID
            response = client.delete('/api/admin/users/some_user_id', 
                                   headers=admin_headers)
            # This should return 404 for non-existent user or 200 for successful deletion
            assert response.status_code in [200, 404]
    
    def test_get_patients_admin(self, client, admin_headers):
        """Test getting patients as admin."""
        if admin_headers:
            response = client.get('/api/admin/patients', headers=admin_headers)
            assert response.status_code == 200
            data = response.get_json()
            assert 'patients' in data
    
    def test_get_conditions_admin(self, client, admin_headers):
        """Test getting medical conditions as admin."""
        if admin_headers:
            response = client.get('/api/admin/conditions', headers=admin_headers)
            assert response.status_code == 200
            data = response.get_json()
            assert 'conditions' in data
    
    def test_get_specialties_admin(self, client, admin_headers):
        """Test getting specialties as admin."""
        if admin_headers:
            response = client.get('/api/admin/specialties', headers=admin_headers)
            assert response.status_code == 200
            data = response.get_json()
            assert 'specialties' in data 