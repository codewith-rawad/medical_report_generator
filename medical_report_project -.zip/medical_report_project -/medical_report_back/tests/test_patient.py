import pytest

class TestPatientRoutes:
    """Test patient management routes."""
    
    def test_create_patient_success(self, client, auth_headers):
        """Test successful patient creation."""
        if auth_headers:
            patient_data = {
                'doctor_id': '507f1f77bcf86cd799439011',  # Mock ObjectId
                'name': 'John Doe',
                'age': 30,
                'address': '123 Main St'
            }
            response = client.post('/api/patients',
                                 json=patient_data,
                                 headers=auth_headers)
            assert response.status_code == 201
            data = response.get_json()
            assert 'message' in data
    
    def test_create_patient_missing_fields(self, client, auth_headers):
        """Test patient creation with missing required fields."""
        if auth_headers:
            incomplete_patient = {
                'name': 'John Doe',
                'age': 30
                # Missing doctor_id
            }
            response = client.post('/api/patients',
                                 json=incomplete_patient,
                                 headers=auth_headers)
            assert response.status_code == 400
    
    def test_get_patients(self, client, auth_headers):
        """Test getting all patients."""
        if auth_headers:
            response = client.get('/api/patients?doctor_id=507f1f77bcf86cd799439011', 
                                headers=auth_headers)
            assert response.status_code == 200
            data = response.get_json()
            assert 'patients' in data
    
    def test_get_patients_missing_doctor_id(self, client, auth_headers):
        """Test getting patients without doctor_id parameter."""
        if auth_headers:
            response = client.get('/api/patients', headers=auth_headers)
            assert response.status_code == 400
    
    def test_get_patients_with_pagination(self, client, auth_headers):
        """Test getting patients with pagination."""
        if auth_headers:
            response = client.get('/api/patients?doctor_id=507f1f77bcf86cd799439011&page=1&limit=10', 
                                headers=auth_headers)
            assert response.status_code == 200
            data = response.get_json()
            assert 'patients' in data
            assert 'page' in data
            assert 'limit' in data
            assert 'total_patients' in data
            assert 'total_pages' in data
    
    def test_delete_patient(self, client, auth_headers):
        """Test deleting a patient."""
        if auth_headers:
            # First create a patient
            patient_data = {
                'doctor_id': '507f1f77bcf86cd799439011',
                'name': 'Jane Doe',
                'age': 25,
                'address': '456 Oak St'
            }
            create_response = client.post('/api/patients',
                                        json=patient_data,
                                        headers=auth_headers)
            
            if create_response.status_code == 201:
                # Delete the patient (using a mock ID since we don't have the actual ID)
                response = client.delete('/api/patients/some_patient_id', 
                                       headers=auth_headers)
                # Should return 404 for non-existent patient or 200 for successful deletion
                assert response.status_code in [200, 404]
    
    def test_get_patient_by_id(self, client, auth_headers):
        """Test getting patient by ID."""
        if auth_headers:
            # Test with a mock patient ID
            response = client.get('/api/patients/some_patient_id', 
                                headers=auth_headers)
            # Should return 404 for non-existent patient
            assert response.status_code == 404 