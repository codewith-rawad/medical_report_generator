import pytest
import json

class TestProfileRoutes:
    """Test profile routes."""
    
    def test_update_profile_success(self, client, auth_headers):
        """Test successful profile update."""
        if auth_headers:
            update_data = {
                '_id': '507f1f77bcf86cd799439011',  # Mock user ID
                'name': 'Updated Name',
                'phone': '1234567890'
            }
            response = client.post('/api/update_profile', 
                                json=update_data, 
                                headers=auth_headers)
            assert response.status_code == 200
            data = response.get_json()
            assert 'message' in data
    
    def test_update_profile_missing_user_id(self, client, auth_headers):
        """Test profile update without user ID."""
        if auth_headers:
            update_data = {
                'name': 'Updated Name',
                'phone': '1234567890'
            }
            response = client.post('/api/update_profile', 
                                json=update_data, 
                                headers=auth_headers)
            assert response.status_code == 400
    
    def test_update_profile_nonexistent_user(self, client, auth_headers):
        """Test profile update for non-existent user."""
        if auth_headers:
            update_data = {
                '_id': 'nonexistent_user_id',
                'name': 'Updated Name',
                'phone': '1234567890'
            }
            response = client.post('/api/update_profile', 
                                json=update_data, 
                                headers=auth_headers)
            assert response.status_code == 404
    
    def test_update_profile_with_all_fields(self, client, auth_headers):
        """Test profile update with all available fields."""
        if auth_headers:
            update_data = {
                '_id': '507f1f77bcf86cd799439011',
                'name': 'Updated Name',
                'phone': '1234567890',
                'address': 'New Address',
                'age': 35,
                'profile_pic': 'new_profile_pic.jpg',
                'specialty': 'Cardiology'
            }
            response = client.post('/api/update_profile', 
                                json=update_data, 
                                headers=auth_headers)
            assert response.status_code == 200
            data = response.get_json()
            assert 'message' in data 