#!/usr/bin/env python3
"""
Script to run all tests with coverage reporting.
"""
import subprocess
import sys
import os

def run_tests():
    """Run all tests with coverage."""
    # Change to the backend directory
    os.chdir('medical_report_back')
    
    # Run tests with coverage
    cmd = [
        'python', '-m', 'pytest',
        '--cov=app',
        '--cov-report=term-missing',
        '--cov-report=html',
        '--cov-report=xml',
        '-v'
    ]
    
    try:
        result = subprocess.run(cmd, check=True)
        print("✅ All tests passed!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Tests failed with exit code {e.returncode}")
        return False

if __name__ == '__main__':
    success = run_tests()
    sys.exit(0 if success else 1) 