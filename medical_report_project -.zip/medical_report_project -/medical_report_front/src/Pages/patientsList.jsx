import React, { useState, useEffect } from 'react';
import { toast, ToastContainer } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import 'react-toastify/dist/ReactToastify.css';
import "../Styles/patientlist.css";
import Background from '../Components/Background';
import img1 from "../assets/background2.jpg";
import img2 from "../assets/background.jpg";
import Back from '../Components/Back';
import { fetchPatients, deletePatient } from '../api/patientApi';

const PatientsList = () => {
  const arr = [img1, img2];
  const navigate = useNavigate();

  const [doctorId, setDoctorId] = useState(null);
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const limit = 3;
  const [totalPages, setTotalPages] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');

  // Modal confirmation states
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [patientToDelete, setPatientToDelete] = useState(null);

  // Fetch patients WITHOUT changing loading state (except initial load)
  const fetchPatientsList = (doctorId, page, limit) => {
    fetchPatients(doctorId, page, limit)
      .then(data => {
        setPatients(data.patients || []);
        setTotalPages(data.total_pages || 1);
      })
      .catch(err => toast.error(err.message, { position: 'top-center' }));
  };

  // Initial load with loading spinner
  useEffect(() => {
    const storedId = localStorage.getItem('doctorId');
    if (!storedId) {
      toast.error('Doctor ID is missing!', { position: 'top-center' });
      setLoading(false);
      return;
    }
    setDoctorId(storedId);
    setLoading(true);
    fetchPatientsList(storedId, page, limit);
    setLoading(false);
  }, [page]);

  // Show modal and set patient id to delete
  const confirmDeletePatient = (id) => {
    setPatientToDelete(id);
    setShowDeleteModal(true);
  };

  // Delete patient and update list
  const handleDeletePatient = () => {
    deletePatient(patientToDelete)
      .then((data) => {
        toast.success(data.message || "Patient deleted successfully", {
          position: 'top-center',
          toastClassName: 'custom-toast',
          autoClose: 3000,
        });
        // Refresh patients list WITHOUT changing loading state
        fetchPatientsList(doctorId, page, limit);
      })
      .catch((err) => toast.error(err.message, { position: 'top-center' }))
      .finally(() => {
        setShowDeleteModal(false);
        setPatientToDelete(null);
      });
  };

  // Navigate handlers
  const handlePatientClick = (patient) => {
    localStorage.setItem('currentPatient', JSON.stringify(patient));
    navigate(`/patient/${patient._id}`);
  };

  const handleAddCase = (patientId) => {
    navigate(`/patient/${patientId}`);
  };

  const handleViewCases = (patientId) => {
    navigate(`/patient-cases/${patientId}`);
  };

  // Pagination controls
  const handlePrevPage = () => {
    if (page > 1) setPage(page - 1);
  };

  const handleNextPage = () => {
    if (page < totalPages) setPage(page + 1);
  };

  // Filter patients by search term
  const filteredPatients = patients.filter(patient =>
    patient.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return <p className="loading-text">Loading patients...</p>;

  return (
    <div className="patientlist-container">
      <h2 className="patientlist-title">Patients List</h2>

      <input
        type="text"
        className="search-input"
        placeholder="Search patients by name..."
        value={searchTerm}
        onChange={e => setSearchTerm(e.target.value)}
      />

      {filteredPatients.length === 0 ? (
        <p className="no-patients-text">No patients found.</p>
      ) : (
        <>
          <ul className="patientlist-ul">
            {filteredPatients.map(patient => (
              <li key={patient._id} className="patientlist-item">
                <div onClick={() => handlePatientClick(patient)} style={{ cursor: 'pointer' }}>
                  <b>{patient.name}</b> — Age: {patient.age}
                </div>
                <div className="patient-actions">
                  <button onClick={() => handleViewCases(patient._id)}>👁 View Cases</button>
                  <button onClick={() => handleAddCase(patient._id)}>➕ Add Case</button>
                  <button
                    onClick={() => confirmDeletePatient(patient._id)}
                    className="delete-btn"
                  >
                    🗑 Delete
                  </button>
                </div>
              </li>
            ))}
          </ul>

          <div className="pagination-controls">
            <button onClick={handlePrevPage} disabled={page === 1}>Prev</button>
            <span>Page {page} of {totalPages}</span>
            <button onClick={handleNextPage} disabled={page === totalPages}>Next</button>
          </div>
        </>
      )}

      {/* Delete Confirmation Modal */}
    {showDeleteModal && (
  <div className="overlay-dark">
    <div className="modal-glass">
      <h3 className="modal-title">Confirm Delete</h3>
      <p className="modal-message sms">Are you sure you want to delete this patient?</p>
      <div className="modal-actions">
        <button onClick={handleDeletePatient} className="btn-danger">Yes, Delete</button>
        <button onClick={() => setShowDeleteModal(false)} className="btn-secondary">Cancel</button>
      </div>
    </div>
  </div>
)}

      <Background images={arr} />
      <ToastContainer />
      <Back link={"/user-profile"} />
    </div>
  );
};

export default PatientsList;
