// src/Pages/Admin.jsx
import React, { useEffect, useState } from 'react';
import '../Styles/Admin.css';
import Background from '../Components/Background';
import Back1 from '../assets/background.jpg';
import Back2 from '../assets/background2.jpg';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {
  fetchUsers, deleteUser, createDoctor, updateUser,
  fetchPatients, deletePatient, createPatient, updatePatient,
  fetchConditions, deleteCondition, createCondition, updateCondition,
  fetchSpecialties, createSpecialty, updateSpecialty, deleteSpecialty,
  fetchDashboardStats
} from '../api/adminApi';

// Shared API Service
const useApiService = () => {
  const [doctors, setDoctors] = useState([]);
  const [patients, setPatients] = useState([]);
  const [specialties, setSpecialties] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState({
    doctors: false,
    patients: false,
    specialties: false,
    stats: false
  });

  // Fetch all doctors
  const fetchAllDoctors = async (search = '') => {
    try {
      setLoading(prev => ({ ...prev, doctors: true }));
      const data = await fetchUsers({ 
        page: 1, 
        perPage: 100, 
        search,
        role: 'doctor'
      });
      setDoctors(data.users || []);
    } catch (error) {
      toast.error('Failed to fetch doctors');
      console.error("Error fetching doctors:", error);
    } finally {
      setLoading(prev => ({ ...prev, doctors: false }));
    }
  };

  // Fetch all patients
  const fetchAllPatients = async (search = '') => {
    try {
      setLoading(prev => ({ ...prev, patients: true }));
      const data = await fetchPatients({
        page: 1,
        perPage: 100,
        search
      });
      setPatients(data.patients || []);
    } catch (error) {
      toast.error('Failed to fetch patients');
    } finally {
      setLoading(prev => ({ ...prev, patients: false }));
    }
  };

  // Fetch all specialties
  const fetchAllSpecialties = async () => {
    try {
      setLoading(prev => ({ ...prev, specialties: true }));
      const data = await fetchSpecialties();
      setSpecialties(data);
    } catch (error) {
      toast.error('Failed to fetch specialties');
    } finally {
      setLoading(prev => ({ ...prev, specialties: false }));
    }
  };

  // Fetch dashboard stats
  const fetchAllStats = async () => {
    try {
      setLoading(prev => ({ ...prev, stats: true }));
      const data = await fetchDashboardStats();
      setStats(data);
    } catch (error) {
      toast.error('Failed to fetch dashboard stats');
    } finally {
      setLoading(prev => ({ ...prev, stats: false }));
    }
  };

  // Initialize all data
  const initializeData = async () => {
    await Promise.all([
      fetchAllDoctors(),
      fetchAllPatients(),
      fetchAllSpecialties(),
      fetchAllStats()
    ]);
  };

  return {
    doctors,
    patients,
    specialties,
    stats,
    loading,
    fetchAllDoctors,
    fetchAllPatients,
    fetchAllSpecialties,
    fetchAllStats,
    initializeData
  };
};

// ========== Shared Components ==========
const Tabs = ({ tabs, activeTab, onTabChange }) => (
  <div className="admin-tabs">
    {tabs.map((tab, idx) => (
      <button
        key={tab}
        className={activeTab === idx ? 'active' : ''}
        onClick={() => onTabChange(idx)}
      >
        {tab}
      </button>
    ))}
  </div>
);

const StatsCard = ({ title, value, icon }) => (
  <div className="stats-card">
    <div className="stats-icon">{icon}</div>
    <div className="stats-content">
      <h3>{title}</h3>
      <p>{value}</p>
    </div>
  </div>
);

const Loader = () => (
  <div className="loadercontainer">
    <div className="loader"></div>
  </div>
);

const NoData = ({ icon, message }) => (
  <div className="no-data">
    <i className={`fas ${icon} no-data-icon`}></i>
    <p>{message}</p>
  </div>
);

const Pagination = ({ page, totalPages, onPageChange }) => (
  <div className="pagination">
    <button 
      onClick={() => onPageChange(Math.max(1, page - 1))} 
      disabled={page === 1}
    >
      <i className="fas fa-chevron-left"></i> Previous
    </button>
    <span>Page {page} of {totalPages}</span>
    <button 
      onClick={() => onPageChange(Math.min(totalPages, page + 1))} 
      disabled={page === totalPages}
    >
      Next <i className="fas fa-chevron-right"></i>
    </button>
  </div>
);

const SearchInput = ({ value, onChange, placeholder }) => (
  <div className="search-container">
    <div className="search-input-container">
      <i className="fas fa-search search-icon"></i>
      <input
        type="text"
        placeholder={placeholder}
        value={value}
        onChange={e => onChange(e.target.value)}
        className="search-input"
      />
    </div>
  </div>
);

const Modal = ({ title, onClose, children, actions }) => (
  <div className="modal-overlay">
    <div className="modal-content">
      <div className="modal-header">
        <h3>{title}</h3>
        <button onClick={onClose} className="close-btn">
          <i className="fas fa-times"></i>
        </button>
      </div>
      {children}
      {actions && <div className="modal-actions">{actions}</div>}
    </div>
  </div>
);

// ========== Dashboard Section ==========
const DashboardSection = ({ stats, loading }) => {
  if (loading.stats) return <Loader />;

  return (
    <div className="admin-section">
      <h2>Dashboard Overview</h2>
      <div className="stats-grid">
        <StatsCard 
          title="Total Doctors" 
          value={stats?.total_doctors || 0} 
          icon={<i className="fas fa-user-md"></i>} 
        />
        <StatsCard 
          title="Total Patients" 
          value={stats?.total_patients || 0} 
          icon={<i className="fas fa-procedures"></i>} 
        />
        <StatsCard 
          title="Medical Conditions" 
          value={stats?.total_conditions || 0} 
          icon={<i className="fas fa-file-medical"></i>} 
        />
        <StatsCard 
          title="Specialties" 
          value={stats?.total_specialties || 0} 
          icon={<i className="fas fa-star-of-life"></i>} 
        />
      </div>
    </div>
  );
};

// ========== Users Section ==========
const UsersSection = ({ specialties, doctors, fetchAllDoctors }) => {
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const perPage = 6;
  const [loading, setLoading] = useState(false);
  const [showAddDoctor, setShowAddDoctor] = useState(false);
  const [showEditDoctor, setShowEditDoctor] = useState(false);
  const [showViewDoctor, setShowViewDoctor] = useState(false);
  
  const initialDoctorState = {
    name: '',
    email: '',
    password: '',
    phone: '',
    address: '',
    age: '',
    specialty_id: ''
  };
  
  const [newDoctor, setNewDoctor] = useState(initialDoctorState);
  const [editDoctor, setEditDoctor] = useState(null);

  const fetchUsersList = async () => {
    try {
      setLoading(true);
      const data = await fetchUsers({ 
        page, 
        perPage, 
        search,
        role: 'doctor'
      });
      setUsers(data.users || []);
      setTotalPages(data.total_pages || 1);
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { 
    fetchUsersList();
    fetchAllDoctors(search);
  }, [page, search]);

  const handleDeleteUser = async (id) => {
    if (window.confirm('Are you sure you want to delete this doctor? All their patients and conditions will also be deleted.')) {
      try {
        await deleteUser(id);
        fetchUsersList();
        fetchAllDoctors();
        toast.success('Doctor deleted successfully!');
      } catch (error) {
        toast.error(error.message);
      }
    }
  };

  const handleAddDoctor = async () => {
    try {
      await createDoctor(newDoctor);
      setShowAddDoctor(false);
      setNewDoctor(initialDoctorState);
      fetchUsersList();
      fetchAllDoctors();
      toast.success('Doctor added successfully!');
    } catch (error) {
      toast.error(error.message);
    }
  };

  const handleEditDoctor = (doctor) => {
    setEditDoctor({ ...doctor });
    setShowEditDoctor(true);
  };

  const handleUpdateDoctor = async () => {
    try {
      await updateUser(editDoctor._id, editDoctor);
      setShowEditDoctor(false);
      setEditDoctor(null);
      fetchUsersList();
      fetchAllDoctors();
      toast.success('Doctor updated successfully!');
    } catch (error) {
      toast.error(error.message);
    }
  };

  const handleViewDoctor = (doctor) => {
    setEditDoctor(doctor);
    setShowViewDoctor(true);
  };

  return (
    <div className="admin-section">
      <div className="section-header">
        <h2>Doctors Management</h2>
        <button 
          className="btn-add"
          onClick={() => setShowAddDoctor(true)}
        >
          <i className="fas fa-plus"></i> Add Doctor
        </button>
      </div>

      {/* Add Doctor Modal */}
      {showAddDoctor && (
        <Modal 
          title="Add New Doctor" 
          onClose={() => setShowAddDoctor(false)}
          actions={
            <>
              <button onClick={() => setShowAddDoctor(false)} className="btn-cancel">
                Cancel
              </button>
              <button onClick={handleAddDoctor} className="btn-confirm">
                Add Doctor
              </button>
            </>
          }
        >
          <div className="form-group">
            <label>Name</label>
            <input
              type="text"
              value={newDoctor.name}
              onChange={(e) => setNewDoctor({...newDoctor, name: e.target.value})}
            />
          </div>
          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              value={newDoctor.email}
              onChange={(e) => setNewDoctor({...newDoctor, email: e.target.value})}
            />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              value={newDoctor.password}
              onChange={(e) => setNewDoctor({...newDoctor, password: e.target.value})}
            />
          </div>
          <div className="form-group">
            <label>Phone</label>
            <input
              type="text"
              value={newDoctor.phone}
              onChange={(e) => setNewDoctor({...newDoctor, phone: e.target.value})}
            />
          </div>
          <div className="form-group">
            <label>Address</label>
            <input
              type="text"
              value={newDoctor.address}
              onChange={(e) => setNewDoctor({...newDoctor, address: e.target.value})}
            />
          </div>
          <div className="form-group">
            <label>Age</label>
            <input
              type="number"
              value={newDoctor.age}
              onChange={(e) => setNewDoctor({...newDoctor, age: e.target.value})}
            />
          </div>
          <div className="form-group">
            <label>Specialty</label>
            <select
              value={newDoctor.specialty_id}
              onChange={(e) => setNewDoctor({...newDoctor, specialty_id: e.target.value})}
            >
              <option value="">Select Specialty</option>
              {specialties.map(spec => (
                <option key={spec._id} value={spec._id}>{spec.name}</option>
              ))}
            </select>
          </div>
        </Modal>
      )}

      {/* Edit Doctor Modal */}
      {showEditDoctor && (
        <Modal 
          title="Edit Doctor" 
          onClose={() => setShowEditDoctor(false)}
          actions={
            <>
              <button onClick={() => setShowEditDoctor(false)} className="btn-cancel">
                Cancel
              </button>
              <button onClick={handleUpdateDoctor} className="btn-confirm">
                Save
              </button>
            </>
          }
        >
          <div className="form-group">
            <label>Name</label>
            <input
              type="text"
              value={editDoctor.name}
              onChange={e => setEditDoctor({ ...editDoctor, name: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              value={editDoctor.email}
              onChange={e => setEditDoctor({ ...editDoctor, email: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label>Phone</label>
            <input
              type="text"
              value={editDoctor.phone}
              onChange={e => setEditDoctor({ ...editDoctor, phone: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label>Address</label>
            <input
              type="text"
              value={editDoctor.address}
              onChange={e => setEditDoctor({ ...editDoctor, address: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label>Age</label>
            <input
              type="number"
              value={editDoctor.age}
              onChange={e => setEditDoctor({ ...editDoctor, age: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label>Specialty</label>
            <select
              value={editDoctor.specialty_id}
              onChange={e => setEditDoctor({ ...editDoctor, specialty_id: e.target.value })}
            >
              <option value="">Select Specialty</option>
              {specialties.map(spec => (
                <option key={spec._id} value={spec._id}>{spec.name}</option>
              ))}
            </select>
          </div>
        </Modal>
      )}

      {/* View Doctor Modal */}
      {showViewDoctor && (
        <Modal 
          title="Doctor Details" 
          onClose={() => setShowViewDoctor(false)}
        >
          <div>
            <p><b>Name:</b> {editDoctor.name}</p>
            <p><b>Email:</b> {editDoctor.email}</p>
            <p><b>Phone:</b> {editDoctor.phone}</p>
            <p><b>Address:</b> {editDoctor.address}</p>
            <p><b>Age:</b> {editDoctor.age}</p>
            <p><b>Specialty:</b> {specialties.find(s => s._id === editDoctor.specialty_id)?.name || 'N/A'}</p>
          </div>
        </Modal>
      )}

      <SearchInput 
        value={search}
        onChange={setSearch}
        placeholder="Search doctors by name or email..."
      />

      {loading ? (
        <Loader />
      ) : (
        <>
          <div className="table-container">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Specialty</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map(user => (
                  <tr key={user._id}>
                    <td>{user.name}</td>
                    <td>{user.email}</td>
                    <td>{user.phone || 'N/A'}</td>
                    <td>
                      {specialties.find(s => s._id === user.specialty_id)?.name || 'N/A'}
                    </td>
                    <td>
                      <div className="action-buttons">
                        <button className="btn-view" onClick={() => handleViewDoctor(user)}>
                          <i className="fas fa-eye"></i>
                        </button>
                        <button className="btn-edit" onClick={() => handleEditDoctor(user)}>
                          <i className="fas fa-edit"></i>
                        </button>
                        <button 
                          className="btn-delete"
                          onClick={() => handleDeleteUser(user._id)}
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {users.length === 0 && (
            <NoData icon="fa-user-md" message="No doctors found" />
          )}

          <Pagination 
            page={page} 
            totalPages={totalPages} 
            onPageChange={setPage} 
          />
        </>
      )}
    </div>
  );
};

// ========== Patients Section ==========
const PatientsSection = ({ specialties, patients, doctors, fetchAllPatients }) => {
  const [filteredPatients, setFilteredPatients] = useState([]);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const perPage = 6;
  const [loading, setLoading] = useState(false);
  const [showAddPatient, setShowAddPatient] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState('');
  
  const initialPatientState = {
    name: '',
    age: '',
    address: '',
    doctor_id: ''
  };
  
  const [newPatient, setNewPatient] = useState(initialPatientState);
  const [showEditPatient, setShowEditPatient] = useState(false);
  const [showViewPatient, setShowViewPatient] = useState(false);
  const [editPatient, setEditPatient] = useState(null);

  const fetchPatientsList = async () => {
    try {
      setLoading(true);
      const data = await fetchPatients({ 
        page, 
        perPage, 
        search,
        doctorId: selectedDoctor
      });
      setFilteredPatients(data.patients || []);
      setTotalPages(data.total_pages || 1);
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { 
    fetchPatientsList();
    if (!selectedDoctor) fetchAllPatients(search);
  }, [page, search, selectedDoctor]);

  const handleDeletePatient = async (id) => {
    if (window.confirm('Are you sure you want to delete this patient? All their medical conditions will also be deleted.')) {
      try {
        await deletePatient(id);
        fetchPatientsList();
        fetchAllPatients();
        toast.success('Patient deleted successfully!');
      } catch (error) {
        toast.error(error.message);
      }
    }
  };

  const handleAddPatient = async () => {
    try {
      await createPatient(newPatient);
      setShowAddPatient(false);
      setNewPatient(initialPatientState);
      fetchPatientsList();
      fetchAllPatients();
      toast.success('Patient added successfully!');
    } catch (error) {
      toast.error(error.message);
    }
  };

  const handleEditPatient = (patient) => {
    setEditPatient({ ...patient });
    setShowEditPatient(true);
  };

  const handleUpdatePatient = async () => {
    try {
      await updatePatient(editPatient._id, editPatient);
      setShowEditPatient(false);
      setEditPatient(null);
      fetchPatientsList();
      fetchAllPatients();
      toast.success('Patient updated successfully!');
    } catch (error) {
      toast.error(error.message);
    }
  };

  const handleViewPatient = (patient) => {
    setEditPatient(patient);
    setShowViewPatient(true);
  };

  return (
    <div className="admin-section">
      <div className="section-header">
        <h2>Patients Management</h2>
        <button 
          className="btn-add"
          onClick={() => setShowAddPatient(true)}
        >
          <i className="fas fa-plus"></i> Add Patient
        </button>
      </div>

      <div className="filters-container">
        <SearchInput 
          value={search}
          onChange={setSearch}
          placeholder="Search patients by name..."
        />
        
        <div className="filter-group">
          <label>Filter by Doctor:</label>
          <select
            value={selectedDoctor}
            onChange={e => { setSelectedDoctor(e.target.value); setPage(1); }}
          >
            <option value="">All Doctors</option>
            {doctors.map(doctor => (
              <option key={doctor._id} value={doctor._id}>
                {doctor.name} 
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Add Patient Modal */}
      {showAddPatient && (
        <Modal 
          title="Add New Patient" 
          onClose={() => setShowAddPatient(false)}
          actions={
            <>
              <button onClick={() => setShowAddPatient(false)} className="btn-cancel">
                Cancel
              </button>
              <button onClick={handleAddPatient} className="btn-confirm">
                Add Patient
              </button>
            </>
          }
        >
          <div className="form-group">
            <label>Name</label>
            <input
              type="text"
              value={newPatient.name}
              onChange={(e) => setNewPatient({...newPatient, name: e.target.value})}
            />
          </div>
          <div className="form-group">
            <label>Age</label>
            <input
              type="number"
              value={newPatient.age}
              onChange={(e) => setNewPatient({...newPatient, age: e.target.value})}
            />
          </div>
          <div className="form-group">
            <label>Address</label>
            <input
              type="text"
              value={newPatient.address}
              onChange={(e) => setNewPatient({...newPatient, address: e.target.value})}
            />
          </div>
          <div className="form-group">
            <label>Doctor</label>
            <select
              value={newPatient.doctor_id}
              onChange={(e) => setNewPatient({...newPatient, doctor_id: e.target.value})}
            >
              <option value="">Select Doctor</option>
              {doctors.map(doctor => (
                <option key={doctor._id} value={doctor._id}>
                  {doctor.name} ({specialties.find(s => s._id === doctor.specialty_id)?.name || 'N/A'})
                </option>
              ))}
            </select>
          </div>
        </Modal>
      )}

      {/* Edit Patient Modal */}
      {showEditPatient && (
        <Modal 
          title="Edit Patient" 
          onClose={() => setShowEditPatient(false)}
          actions={
            <>
              <button onClick={() => setShowEditPatient(false)} className="btn-cancel">
                Cancel
              </button>
              <button onClick={handleUpdatePatient} className="btn-confirm">
                Save
              </button>
            </>
          }
        >
          <div className="form-group">
            <label>Name</label>
            <input
              type="text"
              value={editPatient.name}
              onChange={e => setEditPatient({ ...editPatient, name: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label>Age</label>
            <input
              type="number"
              value={editPatient.age}
              onChange={e => setEditPatient({ ...editPatient, age: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label>Address</label>
            <input
              type="text"
              value={editPatient.address}
              onChange={e => setEditPatient({ ...editPatient, address: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label>Doctor</label>
            <select
              value={editPatient.doctor_id}
              onChange={e => setEditPatient({ ...editPatient, doctor_id: e.target.value })}
            >
              <option value="">Select Doctor</option>
              {doctors.map(doctor => (
                <option key={doctor._id} value={doctor._id}>
                  {doctor.name} ({specialties.find(s => s._id === doctor.specialty_id)?.name || 'N/A'})
                </option>
              ))}
            </select>
          </div>
        </Modal>
      )}

      {/* View Patient Modal */}
      {showViewPatient && (
        <Modal 
          title="Patient Details" 
          onClose={() => setShowViewPatient(false)}
        >
          <div>
            <p><b>Name:</b> {editPatient?.name}</p>
            <p><b>Age:</b> {editPatient?.age}</p>
            <p><b>Address:</b> {editPatient?.address}</p>
            <p><b>Doctor:</b> {doctors.find(d => d._id === editPatient?.doctor_id)?.name || 'N/A'}</p>
          </div>
        </Modal>
      )}

      {loading ? (
        <Loader />
      ) : (
        <>
          <div className="table-container">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Age</th>
                  <th>Address</th>
                  <th>Doctor</th>
                  <th>Conditions</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredPatients.map(patient => (
                  <tr key={patient._id}>
                    <td>{patient.name}</td>
                    <td>{patient.age || 'N/A'}</td>
                    <td>{patient.address || 'N/A'}</td>
                    <td>
                      {doctors.find(d => d._id === patient.doctor_id)?.name || 'N/A'}
                    </td>
                    <td>{patient.medical_cases?.length || 0}</td>
                    <td>
                      <div className="action-buttons">
                        <button className="btn-view" onClick={() => handleViewPatient(patient)}>
                          <i className="fas fa-eye"></i>
                        </button>
                        <button className="btn-edit" onClick={() => handleEditPatient(patient)}>
                          <i className="fas fa-edit"></i>
                        </button>
                        <button 
                          className="btn-delete"
                          onClick={() => handleDeletePatient(patient._id)}
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredPatients.length === 0 && (
            <NoData icon="fa-procedures" message="No patients found" />
          )}

          <Pagination 
            page={page} 
            totalPages={totalPages} 
            onPageChange={setPage} 
          />
        </>
      )}
    </div>
  );
};

// ========== Conditions Section ==========
const ConditionsSection = ({ patients, doctors, specialties, fetchAllPatients }) => {
  const [conditions, setConditions] = useState([]);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const perPage = 100;
  const [loading, setLoading] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState('');
  const [showAddCondition, setShowAddCondition] = useState(false);
  const [showEditCondition, setShowEditCondition] = useState(false);
  const [showViewCondition, setShowViewCondition] = useState(false);
  const [editCondition, setEditCondition] = useState(null);
  
  const initialConditionState = {
    patient_id: '',
    clinical_case: '',
  };
  
  const [newCondition, setNewCondition] = useState(initialConditionState);

  const fetchConditionsList = async () => {
    try {
      setLoading(true);
      const data = await fetchConditions({ 
        page, 
        perPage, 
        search,
        patientId: selectedPatient,
      });
      setConditions(data.conditions || []);
      setTotalPages(data.total_pages || 1);
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { 
    fetchConditionsList();
    if (!selectedPatient) fetchAllPatients(search);
  }, [page, search, selectedPatient]);

  const handleDeleteCondition = async (id) => {
    if (window.confirm('Are you sure you want to delete this medical condition?')) {
      try {
        await deleteCondition(id);
        fetchConditionsList();
        toast.success('Condition deleted successfully!');
      } catch (error) {
        toast.error(error.message);
      }
    }
  };

  const handleAddCondition = async () => {
    try {
      await createCondition(newCondition);
      setShowAddCondition(false);
      setNewCondition(initialConditionState);
      fetchConditionsList();
      toast.success('Condition added successfully!');
    } catch (error) {
      toast.error(error.message);
    }
  };

  const handleEditCondition = (condition) => {
    setEditCondition({ ...condition });
    setShowEditCondition(true);
  };

  const handleUpdateCondition = async () => {
    try {
      await updateCondition(editCondition._id, editCondition);
      setShowEditCondition(false);
      setEditCondition(null);
      fetchConditionsList();
      toast.success('Condition updated successfully!');
    } catch (error) {
      toast.error(error.message);
    }
  };

  const handleViewCondition = (condition) => {
    setEditCondition(condition);
    setShowViewCondition(true);
  };

  return (
    <div className="admin-section">
      <div className="section-header">
        <h2>Medical Conditions</h2>
        <button 
          className="btn-add"
          onClick={() => setShowAddCondition(true)}
        >
          <i className="fas fa-plus"></i> Add Condition
        </button>
      </div>

      <div className="filters-container">
        <SearchInput 
          value={search}
          onChange={setSearch}
          placeholder="Search by clinical case..."
        />
        
        <div className="filter-group">
          <label>Filter by Patient:</label>
          <select
            value={selectedPatient}
            onChange={(e) => { setSelectedPatient(e.target.value); setPage(1); }}
          >
            <option value="">All Patients</option>
            {patients.map(patient => (
              <option key={patient._id} value={patient._id}>
                {patient.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Add Condition Modal */}
      {showAddCondition && (
        <Modal 
          title="Add Condition" 
          onClose={() => setShowAddCondition(false)}
          actions={
            <>
              <button onClick={() => setShowAddCondition(false)} className="btn-cancel">
                Cancel
              </button>
              <button onClick={handleAddCondition} className="btn-confirm">
                Add
              </button>
            </>
          }
        >
          <div className="form-group">
            <label>Patient</label>
            <select
              value={newCondition.patient_id}
              onChange={e => setNewCondition({ ...newCondition, patient_id: e.target.value })}
            >
              <option value="">Select Patient</option>
              {patients.map(patient => (
                <option key={patient._id} value={patient._id}>{patient.name}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Clinical Case</label>
            <input
              type="text"
              value={newCondition.clinical_case}
              onChange={e => setNewCondition({ ...newCondition, clinical_case: e.target.value })}
            />
          </div>
        </Modal>
      )}

      {/* Edit Condition Modal */}
      {showEditCondition && (
        <Modal 
          title="Edit Condition" 
          onClose={() => setShowEditCondition(false)}
          actions={
            <>
              <button onClick={() => setShowEditCondition(false)} className="btn-cancel">
                Cancel
              </button>
              <button onClick={handleUpdateCondition} className="btn-confirm">
                Save
              </button>
            </>
          }
        >
          <div className="form-group">
            <label>Clinical Case</label>
            <input
              type="text"
              value={editCondition.clinical_case}
              onChange={e => setEditCondition({ ...editCondition, clinical_case: e.target.value })}
            />
          </div>
        </Modal>
      )}

      {/* View Condition Modal */}
      {showViewCondition && (
        <Modal 
          title="Condition Details" 
          onClose={() => setShowViewCondition(false)}
        >
          <div>
            <p><b>Patient:</b> {patients.find(p => p._id === editCondition?.patient_id)?.name || 'Unknown'}</p>
            <p><b>Clinical Case:</b> {editCondition?.clinical_case}</p>
            <p><b>Date:</b> {editCondition?.created_at ? new Date(editCondition.created_at).toLocaleDateString() : 'N/A'}</p>
            <p><b>Doctor:</b> {doctors.find(d => d._id === editCondition?.user_id)?.name || 'Unknown'}</p>
          </div>
        </Modal>
      )}

      {loading ? (
        <Loader />
      ) : (
        <>
          <div className="table-container">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Patient</th>
                  <th>Clinical Case</th>
                  <th>Date</th>
                  <th>Doctor</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {conditions.map(condition => {
                  const patient = patients.find(p => p._id === condition.patient_id);
                  const doctor = doctors.find(d => d._id === condition.user_id);
                  return (
                    <tr key={condition._id}>
                      <td>{patient?.name || 'Unknown'}</td>
                      <td>{condition.clinical_case}</td>
                      <td>
                        {condition.created_at ? 
                          new Date(condition.created_at).toLocaleDateString() : 
                          'N/A'
                        }
                      </td>
                      <td>{doctor?.name || 'Unknown'}</td>
                      <td>
                        <div className="action-buttons">
                          <button className="btn-view" onClick={() => handleViewCondition(condition)}>
                            <i className="fas fa-eye"></i>
                          </button>
                          <button className="btn-edit" onClick={() => handleEditCondition(condition)}>
                            <i className="fas fa-edit"></i>
                          </button>
                          <button 
                            className="btn-delete"
                            onClick={() => handleDeleteCondition(condition._id)}
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {conditions.length === 0 && (
            <NoData icon="fa-file-medical" message="No medical conditions found" />
          )}

          <Pagination 
            page={page} 
            totalPages={totalPages} 
            onPageChange={setPage} 
          />
        </>
      )}
    </div>
  );
};

// ========== Specialties Section ==========
const SpecialtiesSection = ({ specialties, fetchAllSpecialties }) => {
  const [newSpecialty, setNewSpecialty] = useState('');
  const [editSpecialtyId, setEditSpecialtyId] = useState(null);
  const [editSpecialtyName, setEditSpecialtyName] = useState('');

  const handleAddSpecialty = async () => {
    if (!newSpecialty.trim()) {
      toast.warning('Please enter a specialty name');
      return;
    }
    try {
      await createSpecialty(newSpecialty);
      setNewSpecialty('');
      fetchAllSpecialties();
      toast.success('Specialty added successfully!');
    } catch (error) {
      toast.error(error.message);
    }
  };

  const handleEditSpecialty = (id, name) => {
    setEditSpecialtyId(id);
    setEditSpecialtyName(name);
  };

  const handleUpdateSpecialty = async () => {
    if (!editSpecialtyName.trim()) {
      toast.warning('Please enter a specialty name');
      return;
    }
    try {
      await updateSpecialty(editSpecialtyId, editSpecialtyName);
      setEditSpecialtyId(null);
      setEditSpecialtyName('');
      fetchAllSpecialties();
      toast.success('Specialty updated successfully!');
    } catch (error) {
      toast.error(error.message);
    }
  };

  const handleDeleteSpecialty = async (id) => {
    if (window.confirm('Are you sure you want to delete this specialty?')) {
      try {
        await deleteSpecialty(id);
        fetchAllSpecialties();
        toast.success('Specialty deleted successfully!');
      } catch (error) {
        toast.error(error.message);
      }
    }
  };

  return (
    <div className="admin-section">
      <h2>Medical Specialties</h2>

      <div className="add-specialty-form">
        <input
          type="text"
          placeholder="Add new specialty"
          value={newSpecialty}
          onChange={e => setNewSpecialty(e.target.value)}
          className="specialty-input"
        />
        <button 
          onClick={handleAddSpecialty}
          className="btn-add"
        >
          <i className="fas fa-plus"></i> Add
        </button>
      </div>

      <div className="specialties-list">
        {specialties.length === 0 ? (
          <NoData icon="fa-star-of-life" message="No specialties found" />
        ) : (
          specialties.map(spec => (
            <div key={spec._id} className="specialty-item">
              {editSpecialtyId === spec._id ? (
                <div className="edit-specialty-form">
                  <input
                    type="text"
                    value={editSpecialtyName}
                    onChange={e => setEditSpecialtyName(e.target.value)}
                    className="specialty-input"
                  />
                  <div className="edit-actions">
                    <button 
                      onClick={handleUpdateSpecialty}
                      className="btn-save"
                    >
                      <i className="fas fa-save"></i> Save
                    </button>
                    <button 
                      onClick={() => setEditSpecialtyId(null)}
                      className="btn-cancel"
                    >
                      <i className="fas fa-times"></i> Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <span className="specialty-name">{spec.name}</span>
                  <div className="specialty-actions">
                    <button 
                      onClick={() => handleEditSpecialty(spec._id, spec.name)}
                      className="btn-edit"
                    >
                      <i className="fas fa-edit"></i>
                    </button>
                    <button 
                      onClick={() => handleDeleteSpecialty(spec._id)}
                      className="btn-delete"
                    >
                      <i className="fas fa-trash"></i>
                    </button>
                  </div>
                </>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

// ========== AdminPage Component ==========
const AdminPage = () => {
  const backgrounds = [Back1, Back2];
  const [activeTab, setActiveTab] = useState(0);
  const apiService = useApiService();

  useEffect(() => {
    apiService.initializeData();
  }, []);

  const tabs = ['Dashboard', 'Doctors', 'Patients', 'Medical Conditions', 'Specialties'];

  return (
    <div className="admin-dashboard">
      <div className="admin-header">
        <h1>
          <i className="fas fa-user-shield"></i> Admin Dashboard
        </h1>
      </div>
      
      <Tabs tabs={tabs} activeTab={activeTab} onTabChange={setActiveTab} />
      
      <div className="admin-tab-content">
        {activeTab === 0 && <DashboardSection stats={apiService.stats} loading={apiService.loading} />}
        {activeTab === 1 && (
          <UsersSection 
            specialties={apiService.specialties} 
            doctors={apiService.doctors}
            fetchAllDoctors={apiService.fetchAllDoctors}
          />
        )}
        {activeTab === 2 && (
          <PatientsSection 
            specialties={apiService.specialties}
            patients={apiService.patients}
            doctors={apiService.doctors}
            fetchAllPatients={apiService.fetchAllPatients}
          />
        )}
        {activeTab === 3 && (
          <ConditionsSection 
            patients={apiService.patients}
            doctors={apiService.doctors}
            specialties={apiService.specialties}
            fetchAllPatients={apiService.fetchAllPatients}
          />
        )}
        {activeTab === 4 && (
          <SpecialtiesSection 
            specialties={apiService.specialties}
            fetchAllSpecialties={apiService.fetchAllSpecialties}
          />
        )}
      </div>
      
      <ToastContainer 
        position="top-right"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
      
      <Background images={backgrounds} />
    </div>
  );
};

export default AdminPage;