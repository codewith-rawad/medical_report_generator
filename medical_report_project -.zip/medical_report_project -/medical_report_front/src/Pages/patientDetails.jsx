import React, { useEffect, useState } from 'react';
import QRCode from "react-qr-code";
import { Link, useNavigate, useParams } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';
import back1 from "../assets/background.jpg";
import back2 from "../assets/background2.jpg";
import Background from '../Components/Background';
import '../Styles/generate_report.css';
import '../Styles/patientDetails.css';
import {
  parsePatientInfo,
  extractKeywords,
  generateVectorReport,
  generateReport,
  saveMedicalCase,
  fetchPatientById,
  fetchUserById,
  generateDirectReport
} from '../api/reportApi';

const GenerateKeywords = () => {
  const backgrounds = [back1, back2];
  const [step, setStep] = useState(0);
  const [patientName, setPatientName] = useState('');
  const [patientAge, setPatientAge] = useState('');
  const [doctorName, setDoctorName] = useState('');
  const [image, setImage] = useState(null);
  const [imageBase64, setImageBase64] = useState('');
  const [selectedModels, setSelectedModels] = useState([]);
  const [selectedVectorModels, setSelectedVectorModels] = useState([]);
  const [keywords, setKeywords] = useState([]);
  const [loading, setLoading] = useState(false);
  const [userId, setUserId] = useState(null);
  const [report, setReport] = useState('');
  const [docxBase64, setDocxBase64] = useState(null);
  const [pdfBase64, setPdfBase64] = useState(null);
  const [imagesWithBoxes, setImagesWithBoxes] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [modalImage, setModalImage] = useState(null);
  const [modalTitle, setModalTitle] = useState('');
  const [clinicalCase, setClinicalCase] = useState('');
  const [qrValue, setQrValue] = useState(null);
  const [directReportMode, setDirectReportMode] = useState(false);
  const [showVectorModels, setShowVectorModels] = useState(false);

  // Standard models for normal report generation
  const standardModels = [
    ['covid-opacity-pneumonia', 'COVID / Opacity / Pneumonia Detection', 'fa-head-side-mask', 'covid'],
    ['tb-detection', 'Tuberculosis Localization', 'fa-lungs', 'tb'],
    ['rib-fracture', 'Rib Fracture Detection', 'fa-x-ray', 'fracture'],
    ['pleural-effusion', 'Pleural Effusion Detection', 'fa-water', 'effusion'],
    ['draw-ribs', 'Visualize Rib Anatomy', 'fa-draw-polygon', 'ribs'],
    ['draw-lungs-heart', 'Visualize Lungs & Heart', 'fa-procedures', 'lungs-heart'],
    ['tumor-classifier', 'Tumor Classifier (Benign / Malignant)', 'fa-microscope', 'tumor'],
    ['tumor-localization', 'Tumor Localization', 'fa-bullseye', 'tumor-loc'],
    ['aortic-conditions', 'Aortic Conditions (Enlargement, Calc., Atel.)', 'fa-heartbeat', 'aortic'],
    ['cardiomegaly', 'Cardiomegaly Detection', 'fa-heart', 'cardio'],
  ];


  const vectorModels = [
    ['detect_segment_vector', 'General Feature Extraction', 'fa-boxes', 'segment'],
    ['benign_detection_vector', 'Benign Detection (YOLO)', 'fa-microscope', 'benign'],
    ['benign_vector', 'Benign Classification (DenseNet)', 'fa-dna', 'benign-class'],
    ['body_vector', 'Body Structure Analysis', 'fa-procedures', 'body'],
    ['covid_vector', 'COVID Detection (EfficientNet)', 'fa-virus', 'covid-vec'],
    ['cardiomegaly_vector', 'Cardiomegaly Analysis', 'fa-heartbeat', 'cardio-vec'],
    ['draw_ribs_vector', 'Rib Structure Analysis', 'fa-bone', 'ribs-vec'],
    ['Tb_vector', 'Tuberculosis Detection', 'fa-lungs-virus', 'tb-vec'],
  ];

  const { transcript, listening, resetTranscript, browserSupportsSpeechRecognition } = useSpeechRecognition();
  const navigate = useNavigate();
  const { patientId } = useParams();

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (!storedUser) {
      navigate('/');
      return;
    }

    const fetchPatientData = async () => {
      try {
        const data1 = await fetchPatientById(patientId);
        const data2 = await fetchUserById(userId);
        setPatientName(data1.name || 'patient');
        setPatientAge(data1.age || "none");
        setDoctorName(data2.name || 'doctor');
      } catch (error) {
        console.error("Failed to fetch patient data:", error);
      }
    };

    if (!browserSupportsSpeechRecognition) {
      toast.error('Your browser does not support speech recognition.');
    }

    try {
      const parsedUser = JSON.parse(storedUser);
      if (!parsedUser._id) {
        navigate('/');
      } else {
        setUserId(parsedUser._id);
        fetchPatientData();
      }
    } catch (err) {
      navigate('/');
    }
  }, [navigate, browserSupportsSpeechRecognition, patientId, userId]);

  const nextStep = () => {
    if (step < 4) setStep(step + 1);
  };

  const prevStep = () => {
    if (step > 0) setStep(step - 1);
  };

  const goToStep = (stepIndex) => {
    setStep(stepIndex);
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    setImage(file);
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64data = reader.result.split(',')[1];
        setImageBase64(base64data);
      };
      reader.readAsDataURL(file);
    } else {
      setImageBase64('');
    }
  };

  const startListening = () => {
    resetTranscript();
    SpeechRecognition.startListening({ continuous: true, language: 'en-US' });
  };

  const stopListening = async () => {
    SpeechRecognition.stopListening();
    if (!transcript.trim()) {
      toast.error('No speech detected to parse.');
      return;
    }
    try {
      const data = await parsePatientInfo(transcript);
      if (data.clinical_case) {
        setClinicalCase(data.clinical_case || transcript);
        setSelectedModels(data.selected_models || []);
        toast.success('Patient info extracted successfully!');
        nextStep();
      } else {
        toast.error(data.message || 'Failed to parse transcript.');
      }
    } catch {
      toast.error('Error connecting to NLP backend.');
    }
  };

  const handleModelChange = (e) => {
    const value = e.target.value;
    setSelectedModels((prev) =>
      prev.includes(value) ? prev.filter((m) => m !== value) : [...prev, value]
    );
  };

  const handleVectorModelChange = (e) => {
    const value = e.target.value;
    setSelectedVectorModels((prev) =>
      prev.includes(value) ? prev.filter((m) => m !== value) : [...prev, value]
    );
  };

  const toggleVectorModels = () => {
    setShowVectorModels(!showVectorModels);
  };

  const handleExtract = async (e) => {
    e.preventDefault();
    if (!image) {
      toast.error('Please upload an image.');
      return;
    }
    if (selectedModels.length === 0) {
      toast.error('Please select at least one model.');
      return;
    }
    if (!userId) {
      toast.error('User not authenticated. Please login again.');
      navigate('/');
      return;
    }
    setLoading(true);
    try {
      const data = await extractKeywords({ image, userId, models: selectedModels });
      setKeywords(data.keywords || []);
      setImagesWithBoxes(data.images_base64 || []);
      toast.success('Keywords extracted successfully!');
      nextStep();
    } catch {
      toast.error('Server connection failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateDirectReport = async (e) => {
    e.preventDefault();
    if (!image) {
      toast.error('Please upload an image.');
      return;
    }
    if (selectedVectorModels.length === 0) {
      toast.error('Please select at least one vector model.');
      return;
    }
    if (!userId) {
      toast.error('User not authenticated. Please login again.');
      navigate('/');
      return;
    }
    setDirectReportMode(true);
    setLoading(true);
    try {
      const data = await generateVectorReport({ image, userId, models: selectedVectorModels });
      const generatedReport = data.report || "No report generated";
      setReport(generatedReport);
      setImagesWithBoxes(data.images_base64 || []);

      const directData = await generateDirectReport({
        userId,
        patientId,
        report: generatedReport
      });
      setDocxBase64(directData.docx_base64);
      setPdfBase64(directData.pdf_base64);

      const baseUrl = "https://codewith-rawad.github.io/Report_Downloader/";
      const today = new Date();
      const reportDate = today.toISOString().split('T')[0];
      const queryParams = new URLSearchParams({
        doctor: doctorName,
        name: patientName,
        age: patientAge,
        date: reportDate,
        report: generatedReport,
      });
      const qrLink = `${baseUrl}?${queryParams.toString()}`;
      setQrValue(qrLink);

      toast.success('Direct report generated and saved successfully!');
      setStep(4);
    } catch (error) {
      toast.error('Server connection failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateReport = async () => {
    if (keywords.length === 0) {
      toast.error('No keywords extracted yet.');
      return;
    }
    if (!clinicalCase.trim()) {
      toast.error('Please fill patient info and clinical case.');
      return;
    }
    if (!userId) {
      toast.error('User not authenticated. Please login again.');
      navigate('/');
      return;
    }
    setDirectReportMode(false);
    setLoading(true);
    try {
      const data = await generateReport({
        userId,
        patientId,
        keywords,
        clinicalCase
      });
      setReport(data.report);
      setDocxBase64(data.docx_base64 || null);
      setPdfBase64(data.pdf_base64 || null);
      toast.success('Report generated successfully!');
      // Generate QR code link
      const baseUrl = "https://codewith-rawad.github.io/Report_Downloader/";
      const today = new Date();
      const reportDate = today.toISOString().split('T')[0];
      const queryParams = new URLSearchParams({
        doctor: doctorName,
        name: patientName,
        age: patientAge,
        date: reportDate,
        report: data.report,
      });
      const qrLink = `${baseUrl}?${queryParams.toString()}`;
      setQrValue(qrLink);
      nextStep();
    } catch {
      toast.error('Server connection failed.');
    } finally {
      setLoading(false);
    }
  };

  const downloadDocxFromBase64 = (base64String, filename) => {
    if (!base64String) {
      toast.error('No Word document available for download.');
      return;
    }
    
    if (directReportMode || !directReportMode) {
      
     
      
    

      const linkSource = `data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,${base64String}`;
      const downloadLink = document.createElement('a');
      downloadLink.href = linkSource;
      downloadLink.download = filename;
      downloadLink.click();
    }
  };

  const downloadPdfFromBase64 = (base64String, filename) => {
    if (!base64String) {
      toast.error('No PDF document available for download.');
      return;
    }
    
     if (directReportMode || !directReportMode) {
      
    
      const linkSource = `data:application/pdf;base64,${base64String}`;
      const downloadLink = document.createElement('a');
      downloadLink.href = linkSource;
      downloadLink.download = filename;
      downloadLink.click();
    }
  };

  const handleSaveCase = async () => {
    if (!patientId) {
      toast.error('Patient ID is required to save.');
      return;
    }
    if (!report) {
      toast.error('Generate report before saving.');
      return;
    }
    if (!imageBase64) {
      toast.error('Image is required to save.');
      return;
    }
    if (!userId) {
      toast.error('User not authenticated. Please login again.');
      navigate('/');
      return;
    }
    setLoading(true);
    try {
      const casePayload = {
        patient_id: patientId,
        clinical_case: clinicalCase,
        pdfBase64: directReportMode ? "direct-report-pdf-base64-placeholder" : pdfBase64,
        docxBase64: directReportMode ? "direct-report-docx-base64-placeholder" : docxBase64,
        report,
        image_base64: imageBase64,
        user_id: userId,
        is_direct_report: directReportMode,
        vector_models: directReportMode ? selectedVectorModels : [],
        standard_models: directReportMode ? [] : selectedModels,
        keywords: directReportMode ? [] : keywords,
        report_date: new Date().toISOString()
      };
      const data = await saveMedicalCase(casePayload);
      if (data && data.error) {
        toast.error(data.error || 'Failed to save medical case.');
      } else {
        toast.success('Medical case saved successfully!');
      }
    } catch {
      toast.error('Server connection failed.');
    } finally {
      setLoading(false);
    }
  };

  if (!userId) {
    return <div className="loading-screen">Loading or Redirecting...</div>;
  }

  return (
    <div className="medical-report-generator">
      <ToastContainer position="top-center" autoClose={3000} />
      <Background images={backgrounds} />

      <div className="report-container">
        <header className="report-header">
          <h1 className="title" style={{padding:"30px", marginTop:"50px"}}>
            <i className="fas fa-file-medical a"></i> Medical Report Generator
          </h1>
          <div className="step-indicator">
            <Link
              to="/patients"
              style={{
                display: 'inline-block',
                padding: '8px 16px',
                margin:"0px 50px 40px",
                backgroundColor: '#689899',
                color: 'white',
                textDecoration: 'none',
                fontWeight: 'bold',
                cursor: 'pointer',
                userSelect: 'none',
                borderRadius:"10px",
                zIndex:"10",
              }}
            >
              ← Back to Patients
            </Link>
            {['Patient', 'Upload', 'Keywords', 'Results', 'Report'].map((label, index) => (
              <div 
                key={index}
                className={`step ${step === index ? 'active' : ''} ${index < step ? 'completed' : ''}`}
                onClick={() => goToStep(index)}
              >
                <div className="step-number">{index + 1}</div>
                <div className="step-label">{label}</div>
              </div>
            ))}
            <div className="progress-bar">
              <div className="progress" style={{ width: `${(step / 4) * 100}%` }}></div>
            </div>
          </div>
        </header>

        <main className="report-content">
          {/* Step 0 - Patient Info */}
          <div className={`step-content ${step === 0 ? 'active' : ''}`}>
            <div className="card patient-card">
              <h2>
                <i className="fas fa-user-injured a"></i> Patient Information
              </h2>
              
              <div className="patient-details">
                <div className="detail-item">
                  <span className="detail-label">Name:</span>
                  <span className="detail-value">{patientName}</span>
                </div>
                <div className="detail-item">
                  <span className="detail-label">Age:</span>
                  <span className="detail-value">{patientAge}</span>
                </div>
                <div className="detail-item">
                  <span className="detail-label">Doctor:</span>
                  <span className="detail-value">{doctorName}</span>
                </div>
              </div>

              <div className="form-group">
                <label htmlFor="clinicalCase">
                  <i className="fas fa-notes-medical a"></i> Clinical Case
                </label>
                <textarea
                  id="clinicalCase"
                  value={clinicalCase}
                  onChange={(e) => setClinicalCase(e.target.value)}
                  placeholder="Enter clinical case details..."
                  rows={5}
                />
              </div>

              <div className="voice-control">
                <div className="voice-buttons">
                  <button
                    type="button"
                    onClick={startListening}
                    disabled={listening}
                    className={`voice-btn ${listening ? 'active' : ''}`}
                  >
                    <i className={`fas fa-microphone${listening ? '' : '-slash'}`}></i>
                    {listening ? ' Listening...' : ' Start Voice Input'}
                  </button>
                  <button
                    type="button"
                    onClick={stopListening}
                    disabled={!listening}
                    className="voice-btn stop"
                  >
                    <i className="fas fa-stop-circle a"></i> Stop & Process
                  </button>
                </div>
                {transcript && (
                  <div className="transcript">
                    <h4>
                      <i className="fas fa-comment-medical a"></i> Voice Input:
                    </h4>
                    <p>{transcript}</p>
                  </div>
                )}
              </div>
            </div>

            <div className="step-actions">
              <button className="btn next-btn" onClick={nextStep}>
                Continue <i className="fas fa-arrow-right "></i>
              </button>
            </div>
          </div>

          {/* Step 1 - Upload + Models */}
          <div className={`step-content ${step === 1 ? 'active' : ''}`}>
            <div className="card">
              <h2>
                <i className="fas fa-upload a"></i> Upload Medical Image
              </h2>
              
              <div className="upload-area">
                <input 
                  type="file" 
                  id="image-upload" 
                  accept="image/*" 
                  onChange={handleImageChange}
                />
                <label htmlFor="image-upload" className="upload-label">
                  {image ? (
                    <div className="image-preview miror">
                      <img src={URL.createObjectURL(image)} alt="Preview" />
                      <span>{image.name}</span>
                    </div>
                  ) : (
                    <>
                      <i className="fas fa-cloud-upload-alt a"></i>
                      <p>Drag & drop your image here or click to browse</p>
                      <small>Supports: JPG, PNG, DICOM</small>
                    </>
                  )}
                </label>
              </div>
            </div>

            <div className="card">
              <div className="models-header">
                <h2>
                  <i className="fas fa-brain a"></i> Select AI Models
                </h2>
                <button 
                  className="toggle-models-btn"
                  onClick={toggleVectorModels}
                >
                  {showVectorModels ? 'Show Standard Models' : 'Show Vector Models (Direct Report)'}
                </button>
              </div>
              
              {showVectorModels ? (
                <div className="model-grid">
                  {vectorModels.map(([value, label, icon, cssClass]) => (
                    <label 
                      key={value} 
                      className={`model-card ${selectedVectorModels.includes(value) ? 'selected' : ''} ${cssClass}`}
                    >
                      <input
                        type="checkbox"
                        value={value}
                        checked={selectedVectorModels.includes(value)}
                        onChange={handleVectorModelChange}
                      />
                      <div className="model-icon">
                        <i className={`fas ${icon}`}></i>
                      </div>
                      <div className="model-name">{label}</div>
                    </label>
                  ))}
                </div>
              ) : (
                <div className="model-grid">
                  {standardModels.map(([value, label, icon, cssClass]) => (
                    <label 
                      key={value} 
                      className={`model-card ${selectedModels.includes(value) ? 'selected' : ''} ${cssClass}`}
                    >
                      <input
                        type="checkbox"
                        value={value}
                        checked={selectedModels.includes(value)}
                        onChange={handleModelChange}
                      />
                      <div className="model-icon">
                        <i className={`fas ${icon}`}></i>
                      </div>
                      <div className="model-name">{label}</div>
                    </label>
                  ))}
                </div>
              )}
            </div>

            <div className="step-actions">
              <button className="btn prev-btn" onClick={prevStep}>
                <i className="fas fa-arrow-left"></i> Back
              </button>
              
              {showVectorModels ? (
                <button 
                  className="btn direct-report-btn"
                  onClick={handleGenerateDirectReport}
                  disabled={loading || !image || selectedVectorModels.length === 0}
                >
                  {loading ? (
                    <>
                      <i className="fas fa-spinner fa-spin a"></i> Generating...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-bolt a"></i> Generate Direct Report
                    </>
                  )}
                </button>
              ) : (
                <button 
                  className="btn next-btn" 
                  onClick={handleExtract}
                  disabled={loading || !image || selectedModels.length === 0}
                >
                  {loading ? (
                    <>
                      <i className="fas fa-spinner fa-spin a"></i> Processing...
                    </>
                  ) : (
                    <>
                      Extract Keywords <i className="fas fa-arrow-right"></i>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>

          {/* Step 2 - Keywords */}
          <div className={`step-content ${step === 2 ? 'active' : ''}`}>
            <div className="card">
              <h2>
                <i className="fas fa-key a"></i> Extracted Medical Keywords
              </h2>
              
              {keywords.length > 0 ? (
                <div className="keywords-container">
                  {keywords.map((kw, idx) => (
                    <span key={idx} className="keyword-tag">
                      {kw}
                    </span>
                  ))}
                </div>
              ) : (
                <div className="empty-state">
                  <i className="fas fa-search a"></i>
                  <p>No keywords extracted yet</p>
                </div>
              )}
            </div>

            <div className="step-actions">
              <button className="btn prev-btn" onClick={prevStep}>
                <i className="fas fa-arrow-left"></i> Back
              </button>
              <button 
                className="btn next-btn" 
                onClick={nextStep}
                disabled={keywords.length === 0}
              >
                View Results <i className="fas fa-arrow-right"></i>
              </button>
            </div>
          </div>

          {/* Step 3 - Model Results */}
          <div className={`step-content ${step === 3 ? 'active' : ''}`}>
            <div className="card">
              <h2>
                <i className="fas fa-images a"></i> AI Model Results
              </h2>
              
              {imagesWithBoxes.length > 0 ? (
                <div className="results-grid">
                  {imagesWithBoxes.map((img, idx) => (
                    <div 
                      key={idx} 
                      className="result-card"
                      onClick={() => {
                        setModalImage(img.image_base64);
                        setModalTitle(img.model);
                        setShowModal(true);
                      }}
                    >
                      <div className="result-image">
                        <img 
                          src={`data:image/jpeg;base64,${img.image_base64}`} 
                          alt={`Model output ${idx}`}
                        />
                      </div>
                      <div className="result-label">
                        {img.model.replace(/-/g, ' ').toUpperCase()}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="empty-state">
                  <i className="fas fa-image a"></i>
                  <p>No model results available</p>
                </div>
              )}
            </div>

            <div className="step-actions">
              <button className="btn prev-btn" onClick={prevStep}>
                <i className="fas fa-arrow-left"></i> Back
              </button>
              <button 
                className="btn next-btn" 
                onClick={handleGenerateReport}
                disabled={loading}
              >
                {loading ? (
                  <>
                    <i className="fas fa-spinner fa-spin a"></i> Generating...
                  </>
                ) : (
                  <>
                    Generate Report <i className="fas fa-arrow-right"></i>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Step 4 - Final Report */}
          <div className={`step-content ${step === 4 ? 'active' : ''}`}>
            <div className="card">
              <h2>
                <i className="fas fa-file-medical-alt a"></i> Medical Report
              </h2>
              
              {report ? (
                <div className="report-content">
                  <div className="report-header">
                    <div className="patient-info">
                      <h3>{patientName}</h3>
                      <p>
                        <strong>Age:</strong> {patientAge} | <strong>Doctor:</strong> {doctorName}
                      </p>
                      <p>
                        <strong>Date:</strong> {new Date().toLocaleDateString()}
                      </p>
                    </div>
                    
                    {qrValue && (
                      <div className="qr-code">
                        <QRCode value={qrValue} size={120} />
                        <p>Scan to view report</p>
                      </div>
                    )}
                  </div>

                  <div className="report-text widthh">
                    <h4>Clinical Case:</h4>
                    <p>{clinicalCase}</p>

                    <h4>Findings:</h4>
                    <textarea 
                      value={report} 
                      readOnly 
                      rows={10}
                      className="report-textarea"
                    />
                  </div>

                  <div className="report-actions">
                    <button 
                      className="btn download-btn"
                      onClick={() => downloadDocxFromBase64(docxBase64, `${patientName}_report.docx`)}
                    >
                      <i className="fas fa-file-word"></i> Download DOCX
                    </button>
                    
                    <button 
                      className="btn download-btn"
                      onClick={() => downloadPdfFromBase64(pdfBase64, `${patientName}_report.pdf`)}
                    >
                      <i className="fas fa-file-pdf a"></i> Download PDF
                    </button>
                    
                    <button 
                      className="btn download-btn"
                      onClick={handleSaveCase}
                      disabled={loading}
                    >
                      {loading ? (
                        <>
                          <i className="fas fa-spinner fa-spin a"></i> Saving...
                        </>
                      ) : (
                        <>
                          <i className="fas fa-save a"></i> Save Case
                        </>
                      )}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="empty-state">
                  <div className="loading-spinner">
                    <i className="fas fa-spinner fa-spin a"></i>
                  </div>
                  <p>Generating your medical report...</p>
                </div>
              )}
            </div>

            <div className="step-actions">
              <button className="btn prev-btn" onClick={prevStep}>
                <i className="fas fa-arrow-left"></i> Back
              </button>
              <button 
                className="btn new-btn"
                onClick={() => {
                  setStep(0);
                  setDirectReportMode(false);
                  setShowVectorModels(false);
                }}
              >
                <i className="fas fa-plus a"></i> New Report
              </button>
            </div>
          </div>
        </main>
      </div>

      {/* Image Preview Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>{modalTitle.replace(/-/g, ' ').toUpperCase()}</h3>
              <button 
                className="modal-close"
                onClick={() => setShowModal(false)}
              >
                <i className="fas fa-times a"></i>
              </button>
            </div>
            <div className="modal-body">
              <img
                src={`data:image/jpeg;base64,${modalImage}`}
                alt="Model Output"
              />
            </div>
            <div className="modal-footer">
              <button 
                className="btn close-btn"
                onClick={() => setShowModal(false)}
              >
                <i className="fas fa-times a"></i> Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GenerateKeywords;