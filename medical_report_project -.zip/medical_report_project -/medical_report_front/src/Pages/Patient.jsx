// AddPatient.jsx
import React, { useState, useEffect } from 'react';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';
import "../Styles/patient.css";
import img1 from "../assets/background2.jpg";
import img2 from "../assets/background.jpg";
import Background from '../Components/Background';
import Back from '../Components/Back';
import { addPatient } from '../api/patientApi';

const AddPatient = () => {
  const arry = [img1, img2];
  const navigate = useNavigate();
  const [doctorId, setDoctorId] = useState(null);
  const [patientData, setPatientData] = useState({
    name: '',
    age: '',
    address: '',
    medicalCases: [],
  });

  useEffect(() => {
    const storedId = localStorage.getItem('doctorId');
    if (storedId) {
      setDoctorId(storedId);
    } else {
      toast.error("Doctor ID is missing!", { position: "top-center" });
    }
  }, []);

  const handleChange = e => {
    setPatientData(prev => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmit = async e => {
    e.preventDefault();

    if (!patientData.name.trim() || !patientData.age.trim()) {
      toast.error("Name and Age are required", { position: "top-center" });
      return;
    }

    if (!doctorId) {
      toast.error("Doctor ID is missing!", { position: "top-center" });
      return;
    }

    const payload = {
      doctor_id: doctorId,
      name: patientData.name,
      age: patientData.age,
      address: patientData.address,
      medical_cases: patientData.medicalCases,
    };

    try {
      const result = await addPatient(payload);
      toast.success('Patient added successfully!', { position: "top-center" });
      localStorage.setItem('currentPatient', JSON.stringify(result));
      setPatientData({ name: '', age: '', address: '', medicalCases: [] });
    } catch (error) {
      toast.error('Error adding patient.', { position: "top-center" });
      console.error(error);
    }
  };

  return (
    <div className="patient-wrapper">
      <div className="patient-cardd">
        <h2 className="patient-title">➕ Add New Patient</h2>

        <form onSubmit={handleSubmit} className="patient-form">
          <label className="patient-label">👤 Name:</label>
          <input
            type="text"
            name="name"
            value={patientData.name}
            onChange={handleChange}
            className="patient-input"
            required
          />

          <label className="patient-label">🎂 Age:</label>
          <input
            type="number"
            name="age"
            value={patientData.age}
            onChange={handleChange}
            className="patient-input"
            required
          />

          <label className="patient-label">📍 Address:</label>
          <input
            type="text"
            name="address"
            value={patientData.address}
            onChange={handleChange}
            className="patient-input"
          />

          <button type="submit" className="patient-submit-btn">💾 Save Patient</button>
        </form>
      </div>
      <ToastContainer />
      <Background images={arry} />
      <Back link={"/user-profile"}/>
      
    </div>
  );
};

export default AddPatient;
