import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';

import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '../Styles/MedicalCondition.css';
import back1 from "../assets/background.jpg"
import back2 from "../assets/background2.jpg"
import Background from '../Components/Background';
import { fetchConditions, deleteCondition } from '../api/conditionApi';

const MedicalConditions = () => {
  const arry=[back1,back2]
  const { patientId } = useParams();
  const [conditions, setConditions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchCase, setSearchCase] = useState('');
  const [searchDate, setSearchDate] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [conditionToDelete, setConditionToDelete] = useState(null);
  const [patientName, setPatientName] = useState('');
  const formatDate = (dateString) => {
  const date = new Date(dateString);

  const day = date.getDate().toString().padStart(2, '0');
  const month = (date.getMonth() + 1).toString().padStart(2, '0'); 
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
};


  const limit = 4;

  const fetchConditionsList = () => {
    if (!patientId) {
      toast.error('Patient ID is missing!');
      return;
    }
    setLoading(true);
    fetchConditions({
      patientId,
      clinical_case: searchCase,
      date: searchDate,
      page,
      limit,
    })
      .then((data) => {
        setConditions(data.conditions || []);
        if (data.conditions?.length > 0) {
          setPatientName(data.conditions[0].patient_name || '');
        }
        setTotalPages(data.total_pages || 1);
      })
      .catch((err) => toast.error(err.message))
      .finally(() => setLoading(false));
  };

  const confirmDelete = (conditionId) => {
    setConditionToDelete(conditionId);
    setShowDeleteModal(true);
  };

  const handleDelete = () => {
    if (!conditionToDelete) return;
    deleteCondition(conditionToDelete)
      .then(() => {
        toast.success('Condition deleted successfully');
        setShowDeleteModal(false);
        fetchConditionsList();
      })
      .catch((err) => toast.error(err.message));
  };

  useEffect(() => {
    fetchConditionsList();
  }, [page, searchCase, searchDate, patientId]);

  return (
    <div className="medical-conditions-container">
   <Link
  to="/patients"
  style={{
    display: 'inline-block',
    padding: '8px 16px',
    backgroundColor: '#004e64',
    color: 'white',
    textDecoration: 'none',
    fontWeight: 'bold',
    cursor: 'pointer',
    userSelect: 'none',
    borderRadius:"10px",
  }}
>
  ← Back to Patients
</Link>
      <h2 className="title">🩺 Medical Conditions</h2>
      <p className="subtitle">for {patientName || 'Loading...'}</p>

      <div className="search-filters">
        <input
          type="text"
          placeholder="Search by clinical case"
          value={searchCase}
          onChange={(e) => setSearchCase(e.target.value)}
        />
        <input
          type="date"
          value={searchDate}
          onChange={(e) => setSearchDate(e.target.value)}
        />
        <button onClick={() => setPage(1)}>Search</button>
      </div>

      {loading ? (
        <p className="loading-text">⏳ Loading...</p>
      ) : conditions.length === 0 ? (
        <p className="no-conditions-text">No medical conditions found.</p>
      ) : (
        <>
          <ul className="conditions-list">
            {conditions.map((cond) => (
            <li key={cond._id} className="condition-item">
  <div className="image-section">
    {cond.image_base64 && (
      <img
        src={`data:image/jpeg;base64,${cond.image_base64}`}
        alt="Medical"
        className="condition-image"
      />
    )}
  </div>

  <div className="details-section">
    <div className="header">
      <span>Age: {cond.age}</span>
      <br />
      <p className="date today">Created at: {formatDate(cond.created_at)}</p>
    </div>

    <p className='cli'><strong>🧾 Clinical Case:</strong> {cond.clinical_case}</p>
    <p><strong>📋 Report Summary:</strong></p>
    <pre className="report-text scrol">{cond.content}</pre>

    {/* ✅ PDF File Icon with Download */}
    {cond.report_base64 && (
      <div className="pdf-download">
        <a style={{color:"red",fontWeight:"500"}}
          href={`data:application/pdf;base64,${cond.report_base64}`}
          download={`report_${cond.patient_name || 'patient'}.pdf`}
          className="pdf-icon"
          title="Download PDF Report"
        >
          📎 PDF File
        </a>
      </div>
    )}

    <button className="delete-button" onClick={() => confirmDelete(cond._id)}>
      🗑 Delete
    </button>
  </div>
</li>

            ))}
          </ul>

          <div className="pagination-controls">
            <button onClick={() => setPage(page - 1)} disabled={page === 1}>⬅ Prev</button>
            <span>Page {page} of {totalPages}</span>
            <button onClick={() => setPage(page + 1)} disabled={page === totalPages}>Next ➡</button>
          </div>
        </>
      )}

      {/* 🔴 Popup Delete Modal */}
   {showDeleteModal && (
  <div className="overlay-dark">
    <div className="modal-glass">
      <h3 className="modal-title">Are you sure?</h3>
      <p className="modal-message sms">Are you sure you want to delete this Medical condition?</p>
      <div className="modal-actions">
        <button className="btn-secondary" onClick={() => setShowDeleteModal(false)}>Cancel</button>
        <button className="btn-danger" onClick={handleDelete}>Yes, Delete</button>
      </div>
    </div>
  </div>
)}

<Background images={arry}/>
      <ToastContainer />
    </div>
  );
};

export default MedicalConditions;
