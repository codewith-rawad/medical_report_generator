// apiHelper.js
export async function apiRequest(url, { method = 'GET', params = {}, body, headers = {}, isFormData = false } = {}) {
 
  let fullUrl = url;
  if (params && Object.keys(params).length > 0) {
    const searchParams = new URLSearchParams(params).toString();
    fullUrl += (url.includes('?') ? '&' : '?') + searchParams;
  }

  const fetchOptions = {
    method,
    headers: isFormData ? headers : { 'Content-Type': 'application/json', ...headers },
    body: body
      ? isFormData
        ? body
        : JSON.stringify(body)
      : undefined,
  };

  const res = await fetch(fullUrl, fetchOptions);

  let result;
  try {
    result = await res.json();
  } catch {
    result = null;
  }

  if (!res.ok) {
    throw new Error(result?.message || 'Request failed');
  }
  return result;
} 