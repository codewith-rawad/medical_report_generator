// API Configuration
export const API_BASE_URL = 'http://127.0.0.1:5000/api';

// Helper function to build full API URLs
export const buildApiUrl = (endpoint) => {
  return `${API_BASE_URL}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`;
}; 