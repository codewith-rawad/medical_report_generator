import { apiRequest } from './apiHelper';
import { buildApiUrl } from './config';

export function updateProfile(data) {
  return apiRequest(buildApiUrl('/update_profile'), {
    method: 'POST',
    body: data
  });
} 