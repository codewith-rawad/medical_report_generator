// src/api/adminApi.js
import { apiRequest } from './apiHelper';
import { buildApiUrl } from './config';

export function fetchUsers({ page, perPage, search, role }) {
  return apiRequest(buildApiUrl('/users'), {
    params: { page, per_page: perPage, search, role: role || '' }
  });
}

export function fetchUser(userId) {
  return apiRequest(buildApiUrl(`/users/${userId}`));
}

export function deleteUser(userId) {
  return apiRequest(buildApiUrl(`/users/${userId}`), { method: 'DELETE' });
}

export function createDoctor(doctorData) {
  return apiRequest(buildApiUrl('/doctors'), {
    method: 'POST',
    body: doctorData
  });
}

export function updateUser(userId, updates) {
  return apiRequest(buildApiUrl(`/users/${userId}`), {
    method: 'PUT',
    body: updates
  });
}

export function fetchPatients({ page, perPage, search, doctorId }) {
  return apiRequest(buildApiUrl('/patients'), {
    params: { page, per_page: perPage, search, doctor_id: doctorId || '' }
  });
}

export function fetchPatient(patientId) {
  return apiRequest(buildApiUrl(`/patients/${patientId}`));
}

export function createPatient(patientData) {
  return apiRequest(buildApiUrl('/patients'), {
    method: 'POST',
    body: patientData
  });
}

export function updatePatient(patientId, updates) {
  return apiRequest(buildApiUrl(`/patients/${patientId}`), {
    method: 'PUT',
    body: updates
  });
}

export function deletePatient(patientId) {
  return apiRequest(buildApiUrl(`/patients/${patientId}`), { method: 'DELETE' });
}

export function fetchConditions({ page, perPage, search, patientId, doctorId }) {
  return apiRequest(buildApiUrl('/conditions'), {
    params: {
      page,
      per_page: perPage,
      search,
      patient_id: patientId || '',
      doctor_id: doctorId || ''
    }
  });
}

export function fetchCondition(conditionId) {
  return apiRequest(buildApiUrl(`/conditions/${conditionId}`));
}

export function deleteCondition(conditionId) {
  return apiRequest(buildApiUrl(`/conditions/${conditionId}`), { method: 'DELETE' });
}

export function createCondition(conditionData) {
  return apiRequest(buildApiUrl('/conditions'), {
    method: 'POST',
    body: conditionData
  });
}

export function updateCondition(conditionId, updates) {
  return apiRequest(buildApiUrl(`/conditions/${conditionId}`), {
    method: 'PUT',
    body: updates
  });
}

export function fetchSpecialties() {
  return apiRequest(buildApiUrl('/specialties'));
}

export function createSpecialty(name) {
  return apiRequest(buildApiUrl('/specialties'), {
    method: 'POST',
    body: { name }
  });
}

export function updateSpecialty(specialtyId, name) {
  return apiRequest(buildApiUrl(`/specialties/${specialtyId}`), {
    method: 'PUT',
    body: { name }
  });
}

export function deleteSpecialty(specialtyId) {
  return apiRequest(buildApiUrl(`/specialties/${specialtyId}`), { method: 'DELETE' });
}

export function fetchDashboardStats() {
  return apiRequest(buildApiUrl('/stats'));
}