// reportApi.js

import { apiRequest } from './apiHelper';
import { buildApiUrl } from './config';

export function parsePatientInfo(transcript) {
  return apiRequest(buildApiUrl('/parse_patient_info'), {
    method: 'POST',
    body: { transcript }
  });
}

export function extractKeywords({ image, userId, models }) {
  const formData = new FormData();
  formData.append('image', image);
  formData.append('user_id', userId);
  models.forEach((model) => formData.append('models', model));
  return apiRequest(buildApiUrl('/extract_keywords'), {
    method: 'POST',
    body: formData,
    isFormData: true
  });
}

export function generateReport({ userId, patientId, keywords, clinicalCase }) {
  return apiRequest(buildApiUrl('/reports/generate'), {
    method: 'POST',
    body: { user_id: userId, patient_id: patientId, keywords, clinical_case: clinicalCase }
  });
}

export function generateVectorReport({ image, userId, models }) {
  const formData = new FormData();
  formData.append('image', image);
  formData.append('user_id', userId);
  models.forEach((model) => formData.append('models', model));
  return apiRequest(buildApiUrl('/generate_vector_report'), {
    method: 'POST',
    body: formData,
    isFormData: true
  });
}

export function saveMedicalCase(payload) {
  return apiRequest(buildApiUrl('/conditions'), {
    method: 'POST',
    body: payload
  });
}

export function fetchPatientById(patientId) {
  return apiRequest(buildApiUrl(`/patients/${patientId}`));
}

export function fetchUserById(userId) {
  return apiRequest(buildApiUrl(`/users/${userId}`));
}

export function generateDirectReport({ userId, patientId, report }) {
  return apiRequest(buildApiUrl('/generate_direct_report'), {
    method: 'POST',
    body: { user_id: userId, patient_id: patientId, report }
  });
} 