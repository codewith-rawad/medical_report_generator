import { apiRequest } from './apiHelper';
import { buildApiUrl } from './config';

export function fetchConditions({ patientId, clinical_case, date, page, limit }) {
  return apiRequest(buildApiUrl('/conditions'), {
    params: {
      patient_id: patientId,
      clinical_case: clinical_case || '',
      date: date || '',
      page,
      limit,
    }
  });
}

export function deleteCondition(conditionId) {
  return apiRequest(buildApiUrl(`/conditions/${conditionId}`), { method: 'DELETE' });
} 