// specialtyApi.js

import { apiRequest } from './apiHelper';
import { buildApiUrl } from './config';

export function fetchSpecialties() {
  return apiRequest(buildApiUrl('/specialties'));
}

export function addSpecialty(name) {
  return apiRequest(buildApiUrl('/specialties'), {
    method: 'POST',
    body: { name }
  });
}

export function updateSpecialty(id, name) {
  return apiRequest(buildApiUrl(`/specialties/${id}`), {
    method: 'PUT',
    body: { name }
  });
}

export function deleteSpecialty(id) {
  return apiRequest(buildApiUrl(`/specialties/${id}`), { method: 'DELETE' });
} 