import { apiRequest } from './apiHelper';
import { buildApiUrl } from './config';

export function addPatient(payload) {
  return apiRequest(buildApiUrl('/patients'), {
    method: 'POST',
    body: payload
  });
}

export function fetchPatients(doctorId, page, limit) {
  return apiRequest(buildApiUrl('/patients'), {
    params: { doctor_id: doctorId, page, limit }
  });
}

export function deletePatient(patientId) {
  return apiRequest(buildApiUrl(`/patients/${patientId}`), { method: 'DELETE' });
} 