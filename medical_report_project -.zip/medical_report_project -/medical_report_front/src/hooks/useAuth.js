import { useState, useEffect } from 'react';
import { jwtDecode } from 'jwt-decode';

export function useAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState('');
  const [tokenExpiration, setTokenExpiration] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const decodedToken = jwtDecode(token);
        if (decodedToken.exp * 1000 < Date.now()) {
          localStorage.removeItem('token');
          setIsAuthenticated(false);
          setUserRole('');
          setTokenExpiration(null);
        } else {
          setIsAuthenticated(true);
          setUserRole(decodedToken.role);
          setTokenExpiration(decodedToken.exp);
        }
      } catch (err) {
        localStorage.removeItem('token');
        setIsAuthenticated(false);
        setUserRole('');
        setTokenExpiration(null);
      }
    }
    setIsLoading(false);
  }, []);

  const onLoginSuccess = (token) => {
    localStorage.setItem('token', token);
    const decodedToken = jwtDecode(token);
    setIsAuthenticated(true);
    setUserRole(decodedToken.role);
    setTokenExpiration(decodedToken.exp);
  };

  const onLogout = () => {
    localStorage.removeItem('token');
    setIsAuthenticated(false);
    setUserRole('');
    setTokenExpiration(null);
  };

  return {
    isAuthenticated,
    userRole,
    tokenExpiration,
    isLoading,
    onLoginSuccess,
    onLogout,
  };
} 