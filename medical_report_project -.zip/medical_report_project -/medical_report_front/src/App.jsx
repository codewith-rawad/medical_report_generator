import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Home from '../src/Pages/Home';
import UserProfile from '../src/Pages/UserProfile';
import AdminPage from '../src/Pages/Admin';
import LoginModal from '../src/Components/LoginModal';
import Navbar from '../src/Components/Navbar';
import SignUp from './Components/Signup';
import About from './Pages/ِAbout';
import Contact from "./Pages/Contact";
import Gallery from './Pages/Gallery';
import GenerateKeywords from './Pages/generate_report';
import AddPatient from './Pages/Patient';
import PatientsList from './Pages/patientsList';
import PatientDetail from './Pages/patientDetails';
import MedicalConditions from './Pages/MedicalConditions';
import "../src/App.css";
import { useAuth } from './hooks/useAuth';
import ProtectedRoute from './Components/ProtectedRoute';

function App() {
  const [showLogin, setShowLogin] = useState(false);
  const [showSignup, setShowSignup] = useState(false);
  const {
    isAuthenticated,
    userRole,
    isLoading,
    onLoginSuccess,
    onLogout,
  } = useAuth();

  const onSignupClick = () => {
    setShowSignup(true);
  };

  return (
    <Router>
      <Navbar 
        isAuthenticated={isAuthenticated} 
        onLogout={onLogout}
        onLoginClick={() => setShowLogin(true)}
        onSignupClick={onSignupClick}
        userRole={userRole}
      />

      {showLogin && (
        <LoginModal 
          onLoginSuccess={onLoginSuccess}
          onClose={() => setShowLogin(false)}
        />
      )}

      {showSignup && (
        <SignUp
          onClose={() => setShowSignup(false)}
        />
      )}

      {!isLoading && ( 
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/About" element={<About />} />
          <Route path="/Contact" element={<Contact />} />
          <Route path="/Gallery" element={<Gallery />} />

          <Route 
            path="/generate-keywords" 
            element={
              <ProtectedRoute isAllowed={isAuthenticated}>
                <GenerateKeywords />
              </ProtectedRoute>
            } 
          />

          <Route 
            path="/patient/:patientId"
            element={
              <ProtectedRoute isAllowed={isAuthenticated}>
                <PatientDetail />
              </ProtectedRoute>
            } 
          />

          <Route 
            path="/patients" 
            element={
              <ProtectedRoute isAllowed={isAuthenticated}>
                <PatientsList/>
              </ProtectedRoute>
            } 
          />

          <Route 
            path="/patient-cases/:patientId" 
            element={
              <ProtectedRoute isAllowed={isAuthenticated}>
                <MedicalConditions/>
              </ProtectedRoute>
            } 
          />

          <Route 
            path="/add-patient" 
            element={
              <ProtectedRoute isAllowed={isAuthenticated}>
                <AddPatient />
              </ProtectedRoute>
            } 
          />
          
          <Route 
            path="/user-profile" 
            element={
              <ProtectedRoute isAllowed={isAuthenticated && userRole === 'doctor'}>
                <UserProfile />
              </ProtectedRoute>
            } 
          />

          <Route 
            path="/admin" 
            element={
              <ProtectedRoute isAllowed={isAuthenticated && userRole === 'admin'}>
                <AdminPage />
              </ProtectedRoute>
            } 
          />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      )}
    </Router>
  );
}

export default App;
