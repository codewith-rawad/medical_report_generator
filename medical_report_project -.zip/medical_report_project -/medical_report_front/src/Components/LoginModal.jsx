import React, { useState, useEffect } from 'react';
import '../Styles/LoginModal.css';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { login, validateEmail, validatePassword } from '../api/authApi';

const LoginModal = ({ onClose, onLoginSuccess }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [emailValid, setEmailValid] = useState(false);
  const [passwordValid, setPasswordValid] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Email validation with debounce
  useEffect(() => {
    const timeoutId = setTimeout(async () => {
      if (email && email.length > 0) {
        try {
          const result = await validateEmail(email);
          if (result.valid) {
            setEmailError('');
            setEmailValid(true);
          } else {
            setEmailError(result.message);
            setEmailValid(false);
          }
        } catch (error) {
          setEmailError('Error validating email');
          setEmailValid(false);
        }
      } else {
        setEmailError('');
        setEmailValid(false);
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [email]);

  // Password validation with debounce
  useEffect(() => {
    const timeoutId = setTimeout(async () => {
      if (password && password.length > 0) {
        try {
          const result = await validatePassword(password);
          if (result.valid) {
            setPasswordError('');
            setPasswordValid(true);
          } else {
            setPasswordError(result.message);
            setPasswordValid(false);
          }
        } catch (error) {
          setPasswordError('Error validating password');
          setPasswordValid(false);
        }
      } else {
        setPasswordError('');
        setPasswordValid(false);
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [password]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Final validation before submission
    if (!emailValid || !passwordValid) {
      toast.error('Please fix validation errors before submitting', {
        position: 'top-center',
        theme: 'colored',
      });
      return;
    }

    setIsLoading(true);

    try {
      const data = await login({ email, password });
      if (data.token) {
        const userData = {
          name: data.user.name,
          email: data.user.email,
          role: data.user.role,
          _id: data.user._id,
          phone: data.user.phone || '',
          address: data.user.address || '',
          age: data.user.age || '',
          profile_pic: data.user.profile_pic || ''
        };
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(userData));
        toast.success('Login successful! 🎉', {
          position: 'top-center',
          theme: 'colored',
        });
        setTimeout(() => {
          onLoginSuccess(data.token);
          onClose();
        }, 2000);
      } else {
        toast.error('Invalid credentials ❌', {
          position: 'top-center',
          theme: 'colored',
        });
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Something went wrong! 😢', {
        position: 'top-center',
        theme: 'colored',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="modal-backdrop">
      <div className="modal">
        <h2>Login</h2>
        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={emailError ? 'error' : emailValid ? 'valid' : ''}
              required
            />
            {emailError && <span className="error-message">{emailError}</span>}
            {emailValid && <span className="success-message">✓ Valid email</span>}
          </div>
          
          <div className="input-group">
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={passwordError ? 'error' : passwordValid ? 'valid' : ''}
              required
            />
            {passwordError && <span className="error-message">{passwordError}</span>}
            {passwordValid && <span className="success-message">✓ Valid password</span>}
          </div>
          
          <button 
            className="modal-btn" 
            type="submit" 
            disabled={isLoading || !emailValid || !passwordValid}
          >
            {isLoading ? 'Logging in...' : 'Login'}
          </button>
        </form>
        <button className="modal-btn close" onClick={onClose}>Close</button>
        <ToastContainer />
      </div>
    </div>
  );
};

export default LoginModal;
