import React from "react";
import { Link } from "react-router-dom"; 
import "../Styles/Back.css";

const Back = ({ link }) => {
  return (
    <div className="div">
      <Link to={link}> 
        <img className="gobackk" src="../src/assets/return.png" alt="Go Back" />
      </Link>
    </div>
  );
};

export default Back;
