import React, { useState, useEffect } from 'react';
import '../Styles/signup.css';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { signup, validateEmail, validatePassword } from '../api/authApi';

const SignUp = ({ onClose }) => {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  // Validation states
  const [errors, setErrors] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const [isValid, setIsValid] = useState({
    username: false,
    email: false,
    password: false,
    confirmPassword: false,
  });

  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // Username validation
  useEffect(() => {
    if (formData.username && formData.username.length > 0) {
      if (formData.username.length < 2) {
        setErrors(prev => ({ ...prev, username: 'Username must be at least 2 characters long' }));
        setIsValid(prev => ({ ...prev, username: false }));
      } else if (!/^[a-zA-Z0-9\s]+$/.test(formData.username)) {
        setErrors(prev => ({ ...prev, username: 'Username can only contain letters, numbers, and spaces' }));
        setIsValid(prev => ({ ...prev, username: false }));
      } else {
        setErrors(prev => ({ ...prev, username: '' }));
        setIsValid(prev => ({ ...prev, username: true }));
      }
    } else {
      setErrors(prev => ({ ...prev, username: '' }));
      setIsValid(prev => ({ ...prev, username: false }));
    }
  }, [formData.username]);

  // Email validation with debounce
  useEffect(() => {
    const timeoutId = setTimeout(async () => {
      if (formData.email && formData.email.length > 0) {
        try {
          const result = await validateEmail(formData.email);
          if (result.valid) {
            setErrors(prev => ({ ...prev, email: '' }));
            setIsValid(prev => ({ ...prev, email: true }));
          } else {
            setErrors(prev => ({ ...prev, email: result.message }));
            setIsValid(prev => ({ ...prev, email: false }));
          }
        } catch (error) {
          setErrors(prev => ({ ...prev, email: 'Error validating email' }));
          setIsValid(prev => ({ ...prev, email: false }));
        }
      } else {
        setErrors(prev => ({ ...prev, email: '' }));
        setIsValid(prev => ({ ...prev, email: false }));
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [formData.email]);

  // Password validation with debounce
  useEffect(() => {
    const timeoutId = setTimeout(async () => {
      if (formData.password && formData.password.length > 0) {
        try {
          const result = await validatePassword(formData.password);
          if (result.valid) {
            setErrors(prev => ({ ...prev, password: '' }));
            setIsValid(prev => ({ ...prev, password: true }));
          } else {
            setErrors(prev => ({ ...prev, password: result.message }));
            setIsValid(prev => ({ ...prev, password: false }));
          }
        } catch (error) {
          setErrors(prev => ({ ...prev, password: 'Error validating password' }));
          setIsValid(prev => ({ ...prev, password: false }));
        }
      } else {
        setErrors(prev => ({ ...prev, password: '' }));
        setIsValid(prev => ({ ...prev, password: false }));
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [formData.password]);

  // Confirm password validation
  useEffect(() => {
    if (formData.confirmPassword && formData.confirmPassword.length > 0) {
      if (formData.confirmPassword !== formData.password) {
        setErrors(prev => ({ ...prev, confirmPassword: 'Passwords do not match' }));
        setIsValid(prev => ({ ...prev, confirmPassword: false }));
      } else {
        setErrors(prev => ({ ...prev, confirmPassword: '' }));
        setIsValid(prev => ({ ...prev, confirmPassword: true }));
      }
    } else {
      setErrors(prev => ({ ...prev, confirmPassword: '' }));
      setIsValid(prev => ({ ...prev, confirmPassword: false }));
    }
  }, [formData.confirmPassword, formData.password]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Final validation before submission
    if (!isValid.username || !isValid.email || !isValid.password || !isValid.confirmPassword) {
      toast.error('Please fix validation errors before submitting', {
        position: 'top-center',
        theme: 'colored',
      });
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast.error('Passwords do not match!', {
        position: 'top-center',
        theme: 'colored',
      });
      return;
    }

    setIsLoading(true);

    try {
      const data = await signup({
        name: formData.username,
        email: formData.email,
        password: formData.password,
      });
      if (data.message === "Doctor account created successfully") {
        toast.success('Sign up successful! 🎉', {
          position: 'top-center',
          theme: 'colored',
        });
        setTimeout(() => {
          onClose();
        }, 2000);
      } else {
        toast.error(`Error: ${data.message}`, {
          position: 'top-center',
          theme: 'colored',
        });
      }
    } catch (error) {
      toast.error('Something went wrong! 😓', {
        position: 'top-center',
        theme: 'colored',
      });
      console.error('Error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getInputClassName = (fieldName) => {
    if (errors[fieldName]) return 'error';
    if (isValid[fieldName]) return 'valid';
    return '';
  };

  return (
    <div className="signup-container">
      <form className="signup-form" onSubmit={handleSubmit}>
        <h2>Create Account</h2>
        
        <div className="input-group">
          <input
            type="text"
            name="username"
            placeholder="Username"
            value={formData.username}
            onChange={handleChange}
            className={getInputClassName('username')}
            required
          />
          {errors.username && <span className="error-message">{errors.username}</span>}
          {isValid.username && <span className="success-message">✓ Valid username</span>}
        </div>

        <div className="input-group">
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
            className={getInputClassName('email')}
            required
          />
          {errors.email && <span className="error-message">{errors.email}</span>}
          {isValid.email && <span className="success-message">✓ Valid email</span>}
        </div>

        <div className="input-group">
          <input
            type="password"
            name="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            className={getInputClassName('password')}
            required
          />
          {errors.password && <span className="error-message">{errors.password}</span>}
          {isValid.password && <span className="success-message">✓ Valid password</span>}
        </div>

        <div className="input-group">
          <input
            type="password"
            name="confirmPassword"
            placeholder="Confirm Password"
            value={formData.confirmPassword}
            onChange={handleChange}
            className={getInputClassName('confirmPassword')}
            required
          />
          {errors.confirmPassword && <span className="error-message">{errors.confirmPassword}</span>}
          {isValid.confirmPassword && <span className="success-message">✓ Passwords match</span>}
        </div>

        <button 
          type="submit" 
          className="modal-btn"
          disabled={isLoading || !isValid.username || !isValid.email || !isValid.password || !isValid.confirmPassword}
        >
          {isLoading ? 'Creating Account...' : 'Sign Up'}
        </button>
        <button type="button" onClick={onClose} className="close-btn modal-btn">Cancel</button>
      </form>

      <ToastContainer />
    </div>
  );
};

export default SignUp;
